package UserInterfaces;

import DataAccessLayer.CourseStorageService.CourseReadOnly;
import DataAccessLayer.ServiceLocator;
import UserInterfaces.Dialogs.DialogLogin;
import UserInterfaces.Dialogs.DialogSignUp;
import DataAccessLayer.UserType;
import javax.swing.JOptionPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import DataModels.Instructor;
import UserInterfaces.Dialogs.DialogInstructorDetails;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import DataAccessLayer.I_CourseStorageService;
import DataAccessLayer.I_SessionService;


/**
 * Represents starting point of the application.
 * This class directly dependent on the service locator.
 * Because, it uses services provided in that.
 * Also, it is responsible for distributing services of the service locator to it's children.
 */
public class MainWindow extends javax.swing.JFrame
{

    public MainWindow(ServiceLocator serviceLocator)
    {
        initComponents();
        updateUI_OnReadyToLogIn();
        
        this.addWindowListener(new OnWindowClosingListener());
        tabbedPanel.addChangeListener(new OnTabChangedListener());
        alignCellTextsToCenter();
        
        this.serviceLocator = serviceLocator;
    }
    
    private void signUp()
    {        
        DialogSignUp dialog = new DialogSignUp(null, true, serviceLocator.getSignUpService());
        dialog.setVisible(true);
    }
    
    private void login()
    {
        DialogLogin dialog = new DialogLogin(null, true, serviceLocator.getLoginService());
        dialog.setVisible(true);
        
        // If user pressed to login button in login dialog, instead of closing the dialog.
        if(serviceLocator.getSessionService().isSessionActive())
        {
            updateUI_OnLoggedIn();
        }
    }
    
    private void logOut()
    {
        int dialogResult = JOptionPane.showConfirmDialog (null, 
                                                         "Do you want to end current session ?", 
                                                         "Log out ?", 
                                                         JOptionPane.YES_NO_OPTION);
        
        if(dialogResult == JOptionPane.YES_OPTION)
        {
            serviceLocator.getSessionService().endCurrentSession();
            updateUI_OnReadyToLogIn();
        }
    }
    
    private void exit()
    {
        int dialogResult = JOptionPane.showConfirmDialog (null, 
                                                          "Do you want to exit ?", 
                                                          "Are you sure ?", 
                                                          JOptionPane.YES_NO_OPTION);
        
        if(dialogResult == JOptionPane.YES_OPTION)
            System.exit(0);
    }
    
    
    /**
     * Upgrades premium status of the current trainee, if it is possible.
     * Assumed business rule is that, only non premium trainees can upgrade
     * and whoever is premium, can't downgrade anymore.
     */
    private void changeToPremium()
    {
        int dialogResult = JOptionPane.showConfirmDialog (null, 
                                                         "Would you like to update your account.", 
                                                         "Upgrade Account ?", 
                                                         JOptionPane.YES_NO_OPTION);
        
        if(dialogResult == JOptionPane.YES_OPTION)
          serviceLocator.getSessionService().setActiveUser_PremiumStatus(true);
        
        refreshAccountInfoTab();
    }
    
    
    /**
     * Renamed version getInstructorDetails().
     */
    private void listInstructors()
    {
        DialogInstructorDetails dialog = new DialogInstructorDetails(null,
            true,
            serviceLocator.getInstructorStorageService().getInstructorList());

        dialog.setVisible(true);
    }
    
    private void listAllCourses()
    {
        clearTableContent(table_OfferedCourses);
        
         fillCourseTableWith(table_OfferedCourses, 
                            serviceLocator.getCourseStorageService().getOfferedCourses());
         
         sortRowsByCourseName(table_OfferedCourses);
    }
    
    private void listEnrolledCourses()
    {
        clearTableContent(table_EnrolledCourses);
        
        fillCourseTableWith(table_EnrolledCourses, 
                            serviceLocator.getSessionService().getActiveUser_EnrolledCourses());
        
        sortRowsByCourseName(table_EnrolledCourses);
    }
    
    private void enrollToSelectedCourse()
    {   
        if(table_OfferedCourses.getSelectedRow() == -1) // If user not made a selection
        {   
            JOptionPane.showMessageDialog(this, 
                                         "To enroll a course please select an item from the list.", 
                                         "Nothing to enroll !", 
                                         JOptionPane.WARNING_MESSAGE);
            
            return;
        }
        
        String requestedCourse = getCourseNameFromSelectedRow(table_OfferedCourses);        
        I_SessionService sessionService = serviceLocator.getSessionService();
        I_CourseStorageService courseStorage = serviceLocator.getCourseStorageService();
        
        // Make an enrollment request.
        boolean isEnrolled = sessionService.setActiveUser_EnrollTo(requestedCourse);
        
        if(isEnrolled)
            listEnrolledCourses();
        else // If request fails, investigate why.
        {   
            if(!courseStorage.isCourseExist(requestedCourse))
            {
                JOptionPane.showMessageDialog(this, 
                                             "The course you're trying to is not exist", 
                                             "Enrollable course not exist !", 
                                             JOptionPane.WARNING_MESSAGE);
            }
            else if(sessionService.isActiveUser_EnrolledTo(requestedCourse))
            {
                JOptionPane.showMessageDialog(this, 
                                              "You can't enroll the same course again.", 
                                              "You're already enrolled.", 
                                              JOptionPane.WARNING_MESSAGE);
            }
            else if(!sessionService.isActiveUser_PremiumMember() 
                    && courseStorage.isPremiumCourse(requestedCourse))
            {
                JOptionPane.showMessageDialog(this, 
                                              "You can't enroll the premium course.", 
                                              "You're not premium member.", 
                                              JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    
    /**
     * Renamed version of deleteCourse().
     */
    private void withdrawFromSelectedCourse()
    {
        if(table_EnrolledCourses.getSelectedRow() == -1) // If user not made a selection
        {
            String title = "Nothing to withdraw !";
            String body = "To withdraw from a course please select an item from the list.";
            
            JOptionPane.showMessageDialog(this, body, title, JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String courseName = getCourseNameFromSelectedRow(table_EnrolledCourses);
        
        // Make withdrawal request.
        boolean isWithdrew = serviceLocator.getSessionService().setActiveUser_WithdrawFrom(courseName);
        
        if(isWithdrew)
            listEnrolledCourses();
        else // If request failed, investiage why.
        {
            if(!serviceLocator.getCourseStorageService().isCourseExist(courseName)) // Although UI is safe-guarded against this, it's still good to check.
            {
                JOptionPane.showMessageDialog(this, "The coure you withdrew is not exist.", 
                                              "Can't withdraw from not-existing course", 
                                              JOptionPane.WARNING_MESSAGE);
            }
            else if(!serviceLocator.getSessionService().isActiveUser_EnrolledTo(courseName))
            {
                JOptionPane.showMessageDialog(this, "You can't withdraw from same course again.", 
                                              "You're already withdrew.", 
                                              JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    private void updateUI_OnReadyToLogIn()
    {
        menu_User.setText("User");
        menuItem_Login.setEnabled(true);
        menuItem_SignUp.setEnabled(true);
        
        tabbedPanel.setEnabledAt(ACCOUNT_INFO_TAB_INDEX, false);
        tabbedPanel.setEnabledAt(COURSE_MANAGEMENT_TAB_INDEX, false);
        
        table_OfferedCourses.setEnabled(false);
        table_EnrolledCourses.setEnabled(false);
        clearTableContent(table_OfferedCourses);
        clearTableContent(table_EnrolledCourses);
        
        
        button_DisplayInstructorList.setEnabled(false);
        button_EnrollToSelectedCourse.setEnabled(false);
        button_WithdrawFromSelectedCourse.setEnabled(false);
        
        menuItem_LogOut.setEnabled(false);
        
        label_NameData.setText("");
        label_SurnameData.setText("");
        label_EmailData.setText("");
        label_GenderData.setText("");
        label_AgeData.setText("");
        label_UserTypeData.setText("");
        label_InstitutionData.setText("");
        label_JobData.setText("");
        label_PositionData.setText("");
        label_CreditData.setText("");
        label_MonthlyFeeData.setText("");
        label_PremiumStatusData.setText("");
        button_UpgradeMembership.setEnabled(false);        
    }
        
    private void updateUI_OnLoggedIn()
    {
        menu_User.setText(serviceLocator.getSessionService().getActiveUser_Email());
        menuItem_LogOut.setEnabled(true);
        tabbedPanel.setEnabledAt(ACCOUNT_INFO_TAB_INDEX, true);
        tabbedPanel.setEnabledAt(COURSE_MANAGEMENT_TAB_INDEX, true);
        
        table_OfferedCourses.setEnabled(true);
        table_EnrolledCourses.setEnabled(true);
        
        button_DisplayInstructorList.setEnabled(true);
        button_EnrollToSelectedCourse.setEnabled(true);
        button_WithdrawFromSelectedCourse.setEnabled(true);
        
        menuItem_Login.setEnabled(false);
        menuItem_SignUp.setEnabled(false);
        
        // Welcome user with up-to-date data which ever tab s/he is in.
        refreshCourseManagementTab();
        refreshAccountInfoTab();
    }
    
    
    /**
     * Updates account info tab for currently logged in trainee.
     */
    private void refreshAccountInfoTab()
    {
        I_SessionService sessionService = serviceLocator.getSessionService();
        
        label_NameData.setText(sessionService.getActiveUser_Name());
        label_SurnameData.setText(sessionService.getActiveUser_Surname());
        label_EmailData.setText(sessionService.getActiveUser_Email());
        label_GenderData.setText(String.valueOf(sessionService.getActiveUser_Gender()));
        label_AgeData.setText(String.valueOf(sessionService.getActiveUser_Age()));
        
        label_CreditData.setText(String.valueOf(sessionService.getActiveUser_Credit()));
        label_MonthlyFeeData.setText(String.valueOf(sessionService.getActiveUser_MonthlyFee()));
        
        UserType userType = sessionService.getActiveUser_Type();
        label_UserTypeData.setText(sessionService.getActiveUser_Type().toString());
        
        if(userType == UserType.STUDENT)
            label_InstitutionData.setText(sessionService.getActiveUser_Institution());
        else
        {
            label_JobData.setText(sessionService.getActiveUser_Job());
            label_PositionData.setText(sessionService.getActiveUser_Position());
        }
        
        if(!sessionService.isActiveUser_PremiumMember())
        {
            label_PremiumStatusData.setText("NO");
            button_UpgradeMembership.setEnabled(true);
        }
        else
        {
            label_PremiumStatusData.setText("YES");
            button_UpgradeMembership.setEnabled(false);
        }
    }
    
    /**
     * Updates tables in the course management tab for currently logged in trainee.
     */
    private void refreshCourseManagementTab()
    {
        listAllCourses();
        listEnrolledCourses();
    }
    
    private void alignCellTextsToCenter()
    {
        DefaultTableCellRenderer centerAlignedRenderer = new DefaultTableCellRenderer();
        centerAlignedRenderer.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        
        table_OfferedCourses.getColumn("Name").setCellRenderer(centerAlignedRenderer);
        table_OfferedCourses.getColumn("Instructor").setCellRenderer(centerAlignedRenderer);
        table_OfferedCourses.getColumn("Duration").setCellRenderer(centerAlignedRenderer);
        
        table_EnrolledCourses.getColumn("Name").setCellRenderer(centerAlignedRenderer);
        table_EnrolledCourses.getColumn("Instructor").setCellRenderer(centerAlignedRenderer);
        table_EnrolledCourses.getColumn("Duration").setCellRenderer(centerAlignedRenderer);
    }
    
    private void sortRowsByCourseName(JTable table)
    {
        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(table.getModel());
        table.setRowSorter(rowSorter);
        List<RowSorter.SortKey> sortKeys = new ArrayList<>();

        int columnIndexToSort = COURSE_NAME_COLUMN_INDEX;
        sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING));

        rowSorter.setSortKeys(sortKeys);
        rowSorter.sort();
    }
    
    private void fillCourseTableWith(JTable table, ArrayList<CourseReadOnly> courses)
    {
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        
        int currentRowIndex;
        Object[] rowData;
        Instructor currentInstructor;
        String instructorColumnText;
        
        table.convertColumnIndexToModel(COURSE_NAME_COLUMN_INDEX);

        for(CourseReadOnly currentCourse : courses)
        {
            currentRowIndex = table.getRowCount();
            
            instructorColumnText = currentCourse.instructorName() 
                                   + currentCourse.instructorSurname();
            
            
            rowData = new Object[]{currentCourse.name(), 
                                   instructorColumnText.toString(), 
                                   currentCourse.duration(), 
                                   currentCourse.isPremium()};
            
            tableModel.insertRow(currentRowIndex, rowData);
        }
    }
    
    private void clearTableContent(JTable table)
    {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);
    }
    
    private String getCourseNameFromSelectedRow(JTable table)
    {
        int selectedRowIndex = table.getSelectedRow();
        
        String result = (String) table.getValueAt(selectedRowIndex, COURSE_NAME_COLUMN_INDEX);
        
        return result;
    }
    
    private ServiceLocator serviceLocator;

    private static final int COURSE_NAME_COLUMN_INDEX = 0;
    
    private static final int COURSE_MANAGEMENT_TAB_INDEX = 0;
    private static final int ACCOUNT_INFO_TAB_INDEX = 1;
    
    
    /**
     * Listener for blocking default close operation of the window.
     */
    private class OnWindowClosingListener extends WindowAdapter
    {
        @Override
        public void windowClosing(WindowEvent we) { exit(); }
    }
    
    
    /**
     * Listener for listening tabbedPanel's tab changes.
     */
    private class OnTabChangedListener implements ChangeListener
    {
        @Override
        public void stateChanged(ChangeEvent ce)
        {
            int index = tabbedPanel.getSelectedIndex();
            
            if(index == ACCOUNT_INFO_TAB_INDEX)
                refreshAccountInfoTab();
            else if(index == COURSE_MANAGEMENT_TAB_INDEX)
                refreshCourseManagementTab();
        }       
    }    

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        tabbedPanel = new javax.swing.JTabbedPane();
        panel_CourseManagement = new javax.swing.JPanel();
        panel_OfferedCourses = new javax.swing.JPanel();
        button_DisplayInstructorList = new javax.swing.JButton();
        label_OfferedCourses = new javax.swing.JLabel();
        scrollPane_OfferedCoursesTable = new javax.swing.JScrollPane();
        table_OfferedCourses = new javax.swing.JTable();
        button_EnrollToSelectedCourse = new javax.swing.JButton();
        panel_EnrolledCourses = new javax.swing.JPanel();
        label_EnrolledCourses = new javax.swing.JLabel();
        scrollPane_EnrolledCoursesTable = new javax.swing.JScrollPane();
        table_EnrolledCourses = new javax.swing.JTable();
        button_WithdrawFromSelectedCourse = new javax.swing.JButton();
        panel_AccountInfo = new javax.swing.JPanel();
        label_Name = new javax.swing.JLabel();
        label_Surname = new javax.swing.JLabel();
        label_Email = new javax.swing.JLabel();
        label_Gender = new javax.swing.JLabel();
        label_Age = new javax.swing.JLabel();
        label_UserType = new javax.swing.JLabel();
        label_Institution = new javax.swing.JLabel();
        label_Job = new javax.swing.JLabel();
        label_Postion = new javax.swing.JLabel();
        label_Credit = new javax.swing.JLabel();
        label_MonthlyFee = new javax.swing.JLabel();
        label_NameData = new javax.swing.JLabel();
        label_SurnameData = new javax.swing.JLabel();
        label_EmailData = new javax.swing.JLabel();
        label_GenderData = new javax.swing.JLabel();
        label_AgeData = new javax.swing.JLabel();
        label_UserTypeData = new javax.swing.JLabel();
        label_InstitutionData = new javax.swing.JLabel();
        label_JobData = new javax.swing.JLabel();
        label_PositionData = new javax.swing.JLabel();
        label_CreditData = new javax.swing.JLabel();
        label_MonthlyFeeData = new javax.swing.JLabel();
        label_PremiumStatus = new javax.swing.JLabel();
        button_UpgradeMembership = new javax.swing.JButton();
        label_PremiumStatusData = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        menu_User = new javax.swing.JMenu();
        menuItem_SignUp = new javax.swing.JMenuItem();
        menuItem_Login = new javax.swing.JMenuItem();
        menuItem_LogOut = new javax.swing.JMenuItem();
        menu_About = new javax.swing.JMenu();
        menuItem_AuthorInfo = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Online Learning Application");

        panel_OfferedCourses.setBackground(new java.awt.Color(190, 232, 231));

        button_DisplayInstructorList.setText("Display instructor list");
        button_DisplayInstructorList.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                button_DisplayInstructorListActionPerformed(evt);
            }
        });

        label_OfferedCourses.setText("Offered Courses:");

        table_OfferedCourses.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Name", "Instructor", "Duration", "Premium Status"
            }
        )
        {
            Class[] types = new Class []
            {
                java.lang.String.class, java.lang.String.class, java.lang.Float.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean []
            {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex)
            {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex)
            {
                return canEdit [columnIndex];
            }
        });
        table_OfferedCourses.getTableHeader().setReorderingAllowed(false);
        scrollPane_OfferedCoursesTable.setViewportView(table_OfferedCourses);
        if (table_OfferedCourses.getColumnModel().getColumnCount() > 0)
        {
            table_OfferedCourses.getColumnModel().getColumn(2).setPreferredWidth(100);
            table_OfferedCourses.getColumnModel().getColumn(2).setMaxWidth(100);
            table_OfferedCourses.getColumnModel().getColumn(3).setPreferredWidth(120);
            table_OfferedCourses.getColumnModel().getColumn(3).setMaxWidth(120);
        }

        button_EnrollToSelectedCourse.setText("Enroll to selected course");
        button_EnrollToSelectedCourse.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                button_EnrollToSelectedCourseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_OfferedCoursesLayout = new javax.swing.GroupLayout(panel_OfferedCourses);
        panel_OfferedCourses.setLayout(panel_OfferedCoursesLayout);
        panel_OfferedCoursesLayout.setHorizontalGroup(
            panel_OfferedCoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_OfferedCoursesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_OfferedCoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrollPane_OfferedCoursesTable, javax.swing.GroupLayout.DEFAULT_SIZE, 886, Short.MAX_VALUE)
                    .addGroup(panel_OfferedCoursesLayout.createSequentialGroup()
                        .addComponent(label_OfferedCourses)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panel_OfferedCoursesLayout.createSequentialGroup()
                        .addComponent(button_EnrollToSelectedCourse)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(button_DisplayInstructorList)))
                .addContainerGap())
        );
        panel_OfferedCoursesLayout.setVerticalGroup(
            panel_OfferedCoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_OfferedCoursesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(label_OfferedCourses)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPane_OfferedCoursesTable, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_OfferedCoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(button_EnrollToSelectedCourse)
                    .addComponent(button_DisplayInstructorList))
                .addContainerGap())
        );

        panel_EnrolledCourses.setBackground(new java.awt.Color(232, 232, 150));

        label_EnrolledCourses.setText("Enrolled Courses:");

        table_EnrolledCourses.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Name", "Instructor", "Duration", "Premium Status"
            }
        )
        {
            Class[] types = new Class []
            {
                java.lang.String.class, java.lang.String.class, java.lang.Float.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean []
            {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex)
            {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex)
            {
                return canEdit [columnIndex];
            }
        });
        table_EnrolledCourses.setShowGrid(true);
        table_EnrolledCourses.getTableHeader().setReorderingAllowed(false);
        scrollPane_EnrolledCoursesTable.setViewportView(table_EnrolledCourses);
        if (table_EnrolledCourses.getColumnModel().getColumnCount() > 0)
        {
            table_EnrolledCourses.getColumnModel().getColumn(2).setPreferredWidth(100);
            table_EnrolledCourses.getColumnModel().getColumn(2).setMaxWidth(100);
            table_EnrolledCourses.getColumnModel().getColumn(3).setPreferredWidth(120);
            table_EnrolledCourses.getColumnModel().getColumn(3).setMaxWidth(120);
        }
        table_EnrolledCourses.getAccessibleContext().setAccessibleName("");

        button_WithdrawFromSelectedCourse.setText("Withdraw from selected course");
        button_WithdrawFromSelectedCourse.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                button_WithdrawFromSelectedCourseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_EnrolledCoursesLayout = new javax.swing.GroupLayout(panel_EnrolledCourses);
        panel_EnrolledCourses.setLayout(panel_EnrolledCoursesLayout);
        panel_EnrolledCoursesLayout.setHorizontalGroup(
            panel_EnrolledCoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_EnrolledCoursesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_EnrolledCoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrollPane_EnrolledCoursesTable)
                    .addGroup(panel_EnrolledCoursesLayout.createSequentialGroup()
                        .addGroup(panel_EnrolledCoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label_EnrolledCourses)
                            .addComponent(button_WithdrawFromSelectedCourse))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panel_EnrolledCoursesLayout.setVerticalGroup(
            panel_EnrolledCoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_EnrolledCoursesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(label_EnrolledCourses)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPane_EnrolledCoursesTable, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(button_WithdrawFromSelectedCourse)
                .addContainerGap())
        );

        javax.swing.GroupLayout panel_CourseManagementLayout = new javax.swing.GroupLayout(panel_CourseManagement);
        panel_CourseManagement.setLayout(panel_CourseManagementLayout);
        panel_CourseManagementLayout.setHorizontalGroup(
            panel_CourseManagementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_CourseManagementLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_CourseManagementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panel_OfferedCourses, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel_EnrolledCourses, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panel_CourseManagementLayout.setVerticalGroup(
            panel_CourseManagementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_CourseManagementLayout.createSequentialGroup()
                .addComponent(panel_OfferedCourses, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel_EnrolledCourses, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabbedPanel.addTab("Course Management", panel_CourseManagement);

        label_Name.setForeground(new java.awt.Color(105, 52, 54));
        label_Name.setText("Name:");

        label_Surname.setForeground(new java.awt.Color(105, 52, 54));
        label_Surname.setText("Surname:");

        label_Email.setForeground(new java.awt.Color(105, 52, 54));
        label_Email.setText("Email:");

        label_Gender.setForeground(new java.awt.Color(105, 52, 54));
        label_Gender.setText("Gender:");

        label_Age.setForeground(new java.awt.Color(105, 52, 54));
        label_Age.setText("Age:");

        label_UserType.setForeground(new java.awt.Color(105, 52, 54));
        label_UserType.setText("User Type:");

        label_Institution.setForeground(new java.awt.Color(50, 90, 120));
        label_Institution.setText("Institution(For Student):");

        label_Job.setForeground(new java.awt.Color(105, 120, 54));
        label_Job.setText("Job(For Non-Student):");

        label_Postion.setForeground(new java.awt.Color(105, 120, 54));
        label_Postion.setText("Postion(Non-Student):");

        label_Credit.setForeground(new java.awt.Color(220, 52, 54));
        label_Credit.setText("Credit:");

        label_MonthlyFee.setForeground(new java.awt.Color(220, 52, 54));
        label_MonthlyFee.setText("Monthly Fee:");

        label_NameData.setText("name goes here");

        label_SurnameData.setText("surname goes here");

        label_EmailData.setText("email goes here");

        label_GenderData.setText("gender");

        label_AgeData.setText("age");

        label_UserTypeData.setText("user type");

        label_InstitutionData.setText("institution goes here");

        label_JobData.setText("job goes here");

        label_PositionData.setText("position goes here");

        label_CreditData.setText("credit goes here");

        label_MonthlyFeeData.setText("monthly fee goes here");

        label_PremiumStatus.setForeground(new java.awt.Color(240, 150, 25));
        label_PremiumStatus.setText("Premium Member:");

        button_UpgradeMembership.setText("Upgrade");
        button_UpgradeMembership.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                button_UpgradeMembershipActionPerformed(evt);
            }
        });

        label_PremiumStatusData.setText("status goes here");

        javax.swing.GroupLayout panel_AccountInfoLayout = new javax.swing.GroupLayout(panel_AccountInfo);
        panel_AccountInfo.setLayout(panel_AccountInfoLayout);
        panel_AccountInfoLayout.setHorizontalGroup(
            panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                        .addComponent(label_Surname)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_SurnameData)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 371, Short.MAX_VALUE)
                        .addComponent(label_PremiumStatus)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_PremiumStatusData)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(button_UpgradeMembership, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                        .addComponent(label_Name)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_NameData))
                    .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                        .addComponent(label_Gender)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_GenderData))
                    .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                        .addComponent(label_Age)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_AgeData))
                    .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                        .addComponent(label_UserType)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_UserTypeData))
                    .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                        .addComponent(label_Institution)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_InstitutionData))
                    .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                        .addComponent(label_Job)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_JobData))
                    .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                        .addComponent(label_Postion)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_PositionData))
                    .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                        .addComponent(label_Credit)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_CreditData))
                    .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                        .addComponent(label_MonthlyFee)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_MonthlyFeeData))
                    .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                        .addComponent(label_Email)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label_EmailData)))
                .addContainerGap())
        );
        panel_AccountInfoLayout.setVerticalGroup(
            panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_AccountInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_Name)
                    .addComponent(label_NameData))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_Surname)
                    .addComponent(label_SurnameData)
                    .addComponent(label_PremiumStatus)
                    .addComponent(button_UpgradeMembership)
                    .addComponent(label_PremiumStatusData))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_Email)
                    .addComponent(label_EmailData))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_Gender)
                    .addComponent(label_GenderData))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_Age)
                    .addComponent(label_AgeData))
                .addGap(12, 12, 12)
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_UserType)
                    .addComponent(label_UserTypeData))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 128, Short.MAX_VALUE)
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_Institution)
                    .addComponent(label_InstitutionData))
                .addGap(12, 12, 12)
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_Job)
                    .addComponent(label_JobData))
                .addGap(12, 12, 12)
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_Postion)
                    .addComponent(label_PositionData))
                .addGap(12, 12, 12)
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_Credit)
                    .addComponent(label_CreditData))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel_AccountInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_MonthlyFee)
                    .addComponent(label_MonthlyFeeData))
                .addGap(6, 6, 6))
        );

        tabbedPanel.addTab("Account Info", panel_AccountInfo);

        menu_User.setText("User");

        menuItem_SignUp.setText("Sign Up");
        menuItem_SignUp.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                menuItem_SignUpActionPerformed(evt);
            }
        });
        menu_User.add(menuItem_SignUp);

        menuItem_Login.setText("Login");
        menuItem_Login.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                menuItem_LoginActionPerformed(evt);
            }
        });
        menu_User.add(menuItem_Login);

        menuItem_LogOut.setText("Log Out");
        menuItem_LogOut.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                menuItem_LogOutActionPerformed(evt);
            }
        });
        menu_User.add(menuItem_LogOut);

        menuBar.add(menu_User);

        menu_About.setText("About");

        menuItem_AuthorInfo.setText("Author Info");
        menuItem_AuthorInfo.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                menuItem_AuthorInfoActionPerformed(evt);
            }
        });
        menu_About.add(menuItem_AuthorInfo);

        menuBar.add(menu_About);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tabbedPanel)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tabbedPanel)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button_UpgradeMembershipActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_button_UpgradeMembershipActionPerformed
    {//GEN-HEADEREND:event_button_UpgradeMembershipActionPerformed
        changeToPremium();
    }//GEN-LAST:event_button_UpgradeMembershipActionPerformed

    private void button_DisplayInstructorListActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_button_DisplayInstructorListActionPerformed
    {//GEN-HEADEREND:event_button_DisplayInstructorListActionPerformed
        listInstructors();
    }//GEN-LAST:event_button_DisplayInstructorListActionPerformed

    private void menuItem_SignUpActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_menuItem_SignUpActionPerformed
    {//GEN-HEADEREND:event_menuItem_SignUpActionPerformed
        signUp();
    }//GEN-LAST:event_menuItem_SignUpActionPerformed

    private void menuItem_LoginActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_menuItem_LoginActionPerformed
    {//GEN-HEADEREND:event_menuItem_LoginActionPerformed
        login();
    }//GEN-LAST:event_menuItem_LoginActionPerformed

    private void menuItem_LogOutActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_menuItem_LogOutActionPerformed
    {//GEN-HEADEREND:event_menuItem_LogOutActionPerformed
        logOut();
    }//GEN-LAST:event_menuItem_LogOutActionPerformed

    private void button_EnrollToSelectedCourseActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_button_EnrollToSelectedCourseActionPerformed
    {//GEN-HEADEREND:event_button_EnrollToSelectedCourseActionPerformed
        enrollToSelectedCourse();
    }//GEN-LAST:event_button_EnrollToSelectedCourseActionPerformed

    private void button_WithdrawFromSelectedCourseActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_button_WithdrawFromSelectedCourseActionPerformed
    {//GEN-HEADEREND:event_button_WithdrawFromSelectedCourseActionPerformed
        withdrawFromSelectedCourse();
    }//GEN-LAST:event_button_WithdrawFromSelectedCourseActionPerformed

    private void menuItem_AuthorInfoActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_menuItem_AuthorInfoActionPerformed
    {//GEN-HEADEREND:event_menuItem_AuthorInfoActionPerformed
        JOptionPane.showMessageDialog(this, "Author: Deniz Yılmazok\nID: 2079465\nCNG 443 Fall 2019\nMETU NCC", "CNG 443 - Assignment 2", WIDTH);
    }//GEN-LAST:event_menuItem_AuthorInfoActionPerformed

    
    /** equivalent of the menu() method.
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        ServiceLocator serviceLocator = new ServiceLocator();
        MainWindow mainWindow = new MainWindow(serviceLocator);
        
        mainWindow.setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton button_DisplayInstructorList;
    private javax.swing.JButton button_EnrollToSelectedCourse;
    private javax.swing.JButton button_UpgradeMembership;
    private javax.swing.JButton button_WithdrawFromSelectedCourse;
    private javax.swing.JLabel label_Age;
    private javax.swing.JLabel label_AgeData;
    private javax.swing.JLabel label_Credit;
    private javax.swing.JLabel label_CreditData;
    private javax.swing.JLabel label_Email;
    private javax.swing.JLabel label_EmailData;
    private javax.swing.JLabel label_EnrolledCourses;
    private javax.swing.JLabel label_Gender;
    private javax.swing.JLabel label_GenderData;
    private javax.swing.JLabel label_Institution;
    private javax.swing.JLabel label_InstitutionData;
    private javax.swing.JLabel label_Job;
    private javax.swing.JLabel label_JobData;
    private javax.swing.JLabel label_MonthlyFee;
    private javax.swing.JLabel label_MonthlyFeeData;
    private javax.swing.JLabel label_Name;
    private javax.swing.JLabel label_NameData;
    private javax.swing.JLabel label_OfferedCourses;
    private javax.swing.JLabel label_PositionData;
    private javax.swing.JLabel label_Postion;
    private javax.swing.JLabel label_PremiumStatus;
    private javax.swing.JLabel label_PremiumStatusData;
    private javax.swing.JLabel label_Surname;
    private javax.swing.JLabel label_SurnameData;
    private javax.swing.JLabel label_UserType;
    private javax.swing.JLabel label_UserTypeData;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem menuItem_AuthorInfo;
    private javax.swing.JMenuItem menuItem_LogOut;
    private javax.swing.JMenuItem menuItem_Login;
    private javax.swing.JMenuItem menuItem_SignUp;
    private javax.swing.JMenu menu_About;
    private javax.swing.JMenu menu_User;
    private javax.swing.JPanel panel_AccountInfo;
    private javax.swing.JPanel panel_CourseManagement;
    private javax.swing.JPanel panel_EnrolledCourses;
    private javax.swing.JPanel panel_OfferedCourses;
    private javax.swing.JScrollPane scrollPane_EnrolledCoursesTable;
    private javax.swing.JScrollPane scrollPane_OfferedCoursesTable;
    private javax.swing.JTabbedPane tabbedPanel;
    private javax.swing.JTable table_EnrolledCourses;
    private javax.swing.JTable table_OfferedCourses;
    // End of variables declaration//GEN-END:variables
}
