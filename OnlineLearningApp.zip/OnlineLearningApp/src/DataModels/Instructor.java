package DataModels;

/**
 * Represents an actual stored instructor record in the database.
 * Instructor does not have a validator methods for its attributes, 
 * because clients of this class will always instantiate it in a correct state.
*/public class Instructor extends Person
{
    public Instructor(String name, String surname, int ID, String email, String password, char gender, int age)
    {
        super(name, surname, email, password, gender, age);
        setID(ID);
    }

    /**
     * Copy constructor for Instructor.
     * @param other is the source of concrete Instructor instance.
     */
    public Instructor(Instructor other)
    {
        super(other);
        setID(other.getID());
    }

    private int ID;
    public int getID() { return ID; }
    public void setID(int ID) { this.ID = ID; }
}
