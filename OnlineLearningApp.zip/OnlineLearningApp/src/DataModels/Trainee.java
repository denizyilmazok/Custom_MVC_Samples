package DataModels;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Base class for trainee types Student and NonStudent.
 * Represents an part of some stored trainee record in the database.
 * 
 * It also contains, responsibility of checking whether record is valid or not.
 * It contains this responsibility, because data for the records will be provided from outside world.
 * Some integrity checking is deferred to derived classes.
 * 
 * In addition, it defers logic for calculating credit and fee to it's children, because children know what kind of pricing will be made.
 */
public abstract class Trainee extends Person implements IPerformance
{
    public Trainee(String name, String surname, String email, String password, char gender, int age, boolean premiumMember)
    {
        super(name, surname, email, password, gender, age);
        setPremiumMember(premiumMember);
        enrolled = new ArrayList<>();
    }

    /**
     * Allows derived trainee classes to have copy constructor.
     * @param other trainee instance to be copied.
     */
    public Trainee(Trainee other)
    {
        super(other.getName(),
              other.getSurname(),
              other.getEmail(),
              other.getPassword(),
              other.getGender(),
              other.getAge());
        setPremiumMember(other.isPremiumMember());
        enrolled = new ArrayList<>(other.enrolled);
    }
    
    
    /**
     * Performs all available integrity checks on the specified trainee record. 
     * @return true if all of the integrity checks success. And returns false, when, at least on of the checks fail.
     */
    public boolean isTraineeInfoValid()
    {
        ArrayList<Boolean> results = new ArrayList<>(); // Better than boolean[], because there is no need to deal with indexes.
        results.add(isNameValid());
        results.add(isSurnameValid());
        results.add(isEmailValid());
        results.add(isPasswordValid());
        results.add(isGenderValid());
        results.add(isAgeValid());

        if(results.contains(Boolean.FALSE)) return false;
        else return true;
    }
    
    
    /**
     * Performs integrity check for name field of trainee.
     * @return true if name field is valid, otherwise, returns false.
     */
    public boolean isNameValid() { return isProvidedNameValid(getName()); }

    
    /**
     * Performs integrity check for surname field of trainee.
     * @return true if surname field is valid, otherwise, returns false.
     */
    public boolean isSurnameValid() { return isProvidedNameValid(getSurname()); }

    
    /**
     * Performs integrity check for email field of trainee.
     * @return true if email field is valid, otherwise, returns false.
     */
    public boolean isEmailValid()
    {
        // Eliminate everything null or ""
        boolean isEmailExist = (getEmail() != null) && !(getEmail().isEmpty());
        if(!isEmailExist) return false;

        // Eliminate everything smaller than length of 7.
        // Because minimum accepted format "a@b.com" has length 7
        boolean isLengthValid = (getEmail().length() >= MINIMAL_ALLOWED_MAIL_FORMAT.length());
        if(!isLengthValid) return false;

        // Only accept individual characters '.', '_' '@' '-' and
        //  characters between a-z, A-Z and 0-9 (both ends inclusive).
        // But, rejects turkish characters  {ı, ğ, ü, ş, ö, ç, İ, Ğ, Ü, Ş, Ö, Ç}
        Pattern allowedCharacters = Pattern.compile("[a-zA-Z0-9._@-]*");
        Matcher matcher = allowedCharacters.matcher(getEmail());
        boolean isCharactersValid = matcher.matches();
        if(!isCharactersValid) return false;

        String[] parts = getEmail().split("@");

        // Eliminate everything, which have different than 2 components when split with "@".
        //  That is, do not accept cases "only-name_no-extension@" or "more@than@one"
        //      Note: Although this part eliminates addresses which has no extension, it does not eliminate empty names.
        //      This case handled in next section.
        boolean isContains_Exactly_One_AtSymbol = (parts.length == 2);
        if(!isContains_Exactly_One_AtSymbol) return false;

        // Do not accept empty name part for email.
        // such as ""@sample.com
        // Because split for '@' above may give empty string at parts[0] when, something like "@sample.com" encountered.
        boolean hasNamePart = !(parts[0].isEmpty());
        if(!hasNamePart) return false;

        // Do not accept if extension part does not contain ALLOWED_MAIL_EXTENSION
        boolean isContainsMailExtension = parts[1].contains(ALLOWED_MAIL_EXTENSION);
        if(!isContainsMailExtension) return false;

        // (Assuming ALLOWED_MAIL_EXTENSION is ".com" below.)
        // Only accept addresses where extension contained only once and at the end of the address.
        //  That is, do not accept such as ".com_in_wrong_place", "more_than_one.com.com" or "weird.comaddress"
        String[] extension = parts[1].split(ALLOWED_MAIL_EXTENSION);
        boolean isMailExtension_Contained_OnlyOnce = (extension.length == 1);
        if(!isMailExtension_Contained_OnlyOnce) return false;

        return true;
    }
    
    
    /**
     * Performs integrity check for password field of trainee.
     * @return true if password field is valid, otherwise, returns false.
     */
    public boolean isPasswordValid()
    {
        String password = getPassword();
        return  (password != null) && !(password.isEmpty()) && (password.length() >= MIN_PASSWORD_LENGTH);
    }
    
    
    /**
     * Performs integrity check for gender field of trainee.
     * @return true if gender field is valid, otherwise, returns false.
     */
    public boolean isGenderValid() 
    {
        char gender = getGender();
        return  (gender == MALE || gender == FEMALE);
    }
    
    
    /**
     * Performs integrity check for age field of trainee.
     * @return true if age field is valid, otherwise, returns false.
     */
    public boolean isAgeValid(){ return (getAge() >= MIN_ALLOWED_AGE && getAge() <= MAX_ALLOWED_AGE); };
    
    
    /**
     * Contains logic for checking whether name and surname are valid or not.
     * @param name is the field wanted to check.
     * @return true if field is valid, otherwise returns false.
     */
    private boolean isProvidedNameValid(String name)
    {
        boolean isNameExist = (name != null) && !(name.isEmpty());
        if(!isNameExist) return false;

        boolean isNameLengthValid = (name.length() >= MIN_ALLOWED_NAME_LENGTH);
        if(!isNameLengthValid) return false;

        // Accept characters between a-z and A-Z (both ends inclusive),
        //  including, turkish characters  {ı, ğ, ü, ş, ö, ç, İ, Ğ, Ü, Ş, Ö, Ç}
        Pattern allowedCharacters = Pattern.compile("[a-zA-ZığüşöçİĞÜŞÖÇ]*");
        Matcher matcher = allowedCharacters.matcher(name);
        boolean isCharactersValid = matcher.matches();
        if(!isCharactersValid) return false;

        return true;
    }


    
    private boolean premiumMember;
    
    /**
     * @return premium membership status of the specified Trainee record.
     */
    public boolean isPremiumMember() { return premiumMember; }
    public void setPremiumMember(boolean premiumMember) { this.premiumMember = premiumMember; }


    /**
     * @param courseToCheck is a course record for checking whether trainee enrolled to that course.
     * @return true if trainee is enrolled to given course, otherwise, returns false.
     */
    public boolean isEnrolledTo(Course courseToCheck)
    {
        return enrolled.contains(courseToCheck);
    }
    
    
    /**
     * Accepts enrollment request for specified trainee record.
     * @param coureseToEnroll course record which represent trainee want to enroll.
     * @return true if enrollment successful, otherwise returns false.
     */
    public boolean enrollTo(Course coureseToEnroll)
    {
        boolean result = false;
        boolean isNotEnrolled = !isEnrolledTo(coureseToEnroll);

        // Only enroll courses which not enrolled before.
        if(isNotEnrolled)
        {
            if(!coureseToEnroll.isPremiumCourse())
            {
                enrolled.add(coureseToEnroll);
                result = true;
            }
            else if(coureseToEnroll.isPremiumCourse() && isPremiumMember())
            {
                enrolled.add(coureseToEnroll);
                result = true;
            }
        }
        
        return result; // If already enrolled
    }

    
    /**
     * Accepts withdrawal request for specified trainee record.
     * @param courseToWithdraw course record which represent trainee want to withdraw.
     * @return true if withdrawal is successful, otherwise returns false.
     */
    public boolean withdrawFrom(Course courseToWithdraw)
    {
        boolean result = false;
        
        // Withdraw when, trainee is enrolled to that course.
        if(isEnrolledTo(courseToWithdraw))
            
        {
            enrolled.remove(courseToWithdraw);
            result = true;
        }
        
        return result;
    }

    
    /**
     * @return copy of the enrolled course list to prevent it from modifications.
     */
    public ArrayList<Course> getEnrolledCourses() { return new ArrayList<>(enrolled); }
    
    public int getNumberOfPremiumCourses()
    {
        int numberOfPremiums = 0;
        Iterator<Course> iterator = getEnrolledCourses().iterator();

        while(iterator.hasNext())
        {
            Course current = iterator.next();
            if(current.isPremiumCourse()) ++numberOfPremiums;
        }

        return numberOfPremiums;
    }

    
    /**
     * Helper function for subclasses to use when calculating fees.
     * @param coefficient is the course pricing coefficient for registration type.
     * @return credits according to registration type.
     */
    protected float calculateCreditFor(float coefficient)
    {
        return  getNumberOfPremiumCourses() * coefficient;
    }
    
    public static final String MINIMAL_ALLOWED_MAIL_FORMAT = "a@b.com";
    public static final String ALLOWED_MAIL_EXTENSION = ".com";

    public static final int MIN_ALLOWED_NAME_LENGTH = 2;
    public static final int MIN_ALLOWED_AGE = 18;
    public static final int MAX_ALLOWED_AGE = 55;
    public static final int MIN_PASSWORD_LENGTH = 3;

    private ArrayList<Course> enrolled;
}