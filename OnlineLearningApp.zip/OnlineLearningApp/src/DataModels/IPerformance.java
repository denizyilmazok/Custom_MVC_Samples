package DataModels;

/**
 * Provides unified interface for calculating fees for different types of trainees.
 */
public interface IPerformance
{
    float credit();

    float monthlyFee();
}
