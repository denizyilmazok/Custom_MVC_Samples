package DataModels;

/**
 * Base class for Trainee and Instructor models.
 */
public abstract class Person
{
    public Person(String name,
                  String surname,
                  String email,
                  String password,
                  char gender,
                  int age)
    {
        fillPersonInfo(name, surname, email, password, gender, age);
    }

    /**
     * Allows derived classes to have copy constructor.
     * @param other person instance to be copied.
     */
    public Person(Person other)
    {
        fillPersonInfo(other.getName(),
                       other.getSurname(),
                       other.getEmail(),
                       other.getPassword(),
                       other.getGender(),
                       other.getAge());
    }


    private String name;
    public String getName() {return name; }
    public void setName(String name) { this.name = name; }

    private String surname;
    public String getSurname() { return surname; }
    public void setSurname(String surname) { this.surname = surname; }
    
    private String email;
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    private String password;
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    private char gender;
    public char getGender() { return gender; }
    public void setGender(char gender) { this.gender = gender; }

    private int age;
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }


    public static final char MALE = 'M', FEMALE = 'F';

    private void fillPersonInfo(String name, String surname, String email, String password, char gender, int age)
    {
        setName(name);
        setSurname(surname);
        setEmail(email);
        setPassword(password);
        setGender(gender);
        setAge(age);
    }
}