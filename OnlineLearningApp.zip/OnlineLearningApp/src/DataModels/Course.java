package DataModels;

/**
 * Represents an actual stored course record in the database.
 * Course does not have a validator methods for its attributes, 
 * because clients of this class will always instantiate it in a correct state.
*/
public class Course
{
    public Course(String name, Instructor instructor, float duration, boolean premiumCourse)
    {
        fillCourseInfo(name, instructor, duration, premiumCourse);
    }

    /**
     * Copy constructor.
     * @param other is the source of concrete Course instance.
     */
    public Course(Course other)
    {
        fillCourseInfo(other.getName(),
                       other.getInstructor(),
                       other.getDuration(),
                       other.isPremiumCourse());
    }

    private String name;
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    private Instructor instructor;
    public Instructor getInstructor() { return instructor; }
    public void setInstructor(Instructor instructor) { this.instructor = instructor; }

    private float duration;
    public float getDuration() { return duration; }
    public void setDuration(float duration) { this.duration = duration; }

    private boolean premiumCourse;
    public boolean isPremiumCourse() { return premiumCourse; }
    public void setPremiumCourse(boolean premiumCourse) { this.premiumCourse = premiumCourse; }

    private void fillCourseInfo(String name,
                                Instructor instructor,
                                float duration,
                                boolean premiumStatus)
    {
        setName(name);
        setInstructor(instructor);
        setDuration(duration);
        setPremiumCourse(premiumStatus);
    }
}
