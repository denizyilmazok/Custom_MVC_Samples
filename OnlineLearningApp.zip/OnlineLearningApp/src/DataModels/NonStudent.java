package DataModels;

/**
 * Represents an actually stored Trainee record for non-student in the database.
 * It also contains, responsibility of checking whether record is valid or not.
 * It contains this responsibility, because data for the records will be provided from outside world.
 * 
 * In addition, it contains logic for calculating credit and fee, because business rules state that, non-students must pay different fee.
 */
public class NonStudent extends Trainee
{
    public NonStudent(String name, String surname, String email, String password, char gender, int age,
                      boolean premiumMember, String job, String position)
    {
        super(name, surname, email, password, gender, age, premiumMember);
        setJob(job);
        setPosition(position);
    }

    public NonStudent(NonStudent other)
    {
        super(other);
        setJob(other.getJob());
        setPosition(other.getPosition());
    }

    /**
     * Copy constructor which accepts student record.
     * @param other can be instance of any type of Trainee.
     * @param job will be the name of the job for new created non-student record.
     * @param position will be the name of the position for new created non-student record.
     */
    public NonStudent(Trainee other, String job, String position)
    {
        super(other);
        setJob(job);
        setPosition(position);
    }

    private String job;
    public String getJob() { return job; }
    public void setJob(String job) { this.job = job; }
    
    
    /**
     * Performs integrity check for job field of trainee.
     * @return true if job field is valid, otherwise, returns false.
     */
    public boolean isJobValid()
    {
        return (getJob() != null) && !(getJob().isEmpty()) && (getJob().length() >= MIN_ALLOWED_JOB_TITLE_LENGTH);
    }

    private String position;
    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }
    
    
    /**
     * Performs integrity check for position field of trainee.
     * @return true if position field is valid, otherwise, returns false.
     */
    public boolean isPositionValid()
    {
        return (getPosition() != null) && !(getPosition().isEmpty()) && (getPosition().length() >= MIN_ALLOWED_JOB_TITLE_LENGTH);
    }

    public static final int MIN_ALLOWED_JOB_TITLE_LENGTH = 2;
    public static final float NON_STUDENT_CREDIT_COEFFICENT = 0.4F;

    
    /**
     * Performs all available integrity checks on the specified non-student record. 
     * @return true if all of the integrity checks success. And returns false, when, at least on of the checks fail.
     */
    @Override
    public boolean isTraineeInfoValid()
    {
        return super.isTraineeInfoValid() && isJobValid() && isPositionValid();
    }

    @Override
    public float credit() { return calculateCreditFor(NON_STUDENT_CREDIT_COEFFICENT); }

    @Override
    public float monthlyFee() { return ((getNumberOfPremiumCourses() * 10) -credit()) * 2; }
}