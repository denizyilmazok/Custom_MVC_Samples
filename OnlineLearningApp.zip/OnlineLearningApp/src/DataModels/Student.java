package DataModels;

/**
 * Represents an actually stored Trainee record for student in the database.
 * It also contains, responsibility of checking whether record is valid or not.
 * It contains this responsibility, because data for the records will be provided from outside world.
 * 
 * In addition, it contains logic for calculating credit and fee, because business rules state that, students must pay different fee.
 */
public class Student extends Trainee
{
    public Student(String name, String surname, String email, String password, String institution, char gender, int age, boolean premiumStatus)
    {
        super(name, surname, email, password, gender, age, premiumStatus);
        setInstitution(institution);
    }

    /**
     * Copy constructor which accepts non-student record.
     * @param other can be instance of any type of Trainee.
     * @param institution will be the name of the institution for new created student record.
     */
    public Student(Trainee other, String institution)
    {
        super(other);
        setInstitution(institution);
    }

    /**
     * 
     * @param other 
     */
    public Student(Student other)
    {
        super(other);
        setInstitution(other.getInstitution());
    }

    private String institution;
    public String getInstitution() { return institution; }
    public void setInstitution(String institution) { this.institution = institution; }
    
    
    /**
     * Performs integrity check for institution field of trainee.
     * @return true if institution field is valid, otherwise, returns false.
     */
    public boolean isInstitutionValid()
    {
        return (getInstitution() != null) && !(getInstitution().isEmpty()) && (getInstitution().length() >= MIN_ALLOWED_INSTITUTION_LENGTH);
    }

    public static final int MIN_ALLOWED_INSTITUTION_LENGTH = 2;
    public static final float STUDENT_CREDIT_COEFFICENT = 0.8F;

    
    /**
     * Performs all available integrity checks on the specified student record. 
     * @return true if all of the integrity checks success. And returns false, when, at least on of the checks fail.
     */
    @Override
    public boolean isTraineeInfoValid() { return super.isTraineeInfoValid()&& isInstitutionValid(); }

    @Override
    public float credit() { return calculateCreditFor(STUDENT_CREDIT_COEFFICENT); }

    @Override
    public float monthlyFee() { return (getNumberOfPremiumCourses() * 10) - credit(); }
}
