package DataAccessLayer;

import DataModels.Course;
import DataModels.Instructor;


/**
 * 
 * Entry point for DAL package. A client code wants to use DAL needs an instance of this class.
 * It abstracts client from initialization of services and provides single point for access to services.
 * 
 * This class is designed to expose limited set of functionality of contained services to the outside world.
 */
public class ServiceLocator
{
    public ServiceLocator()
    { 
        initServices();
        fillDatabases();
    }
    
    
    /**
     * @return I_SignUpService part of the the contained SignUpService.
     */
    public I_SignUpService getSignUpService() { return signUpService; }
    
    /**
     * @return I_LoginService part of the contained LoginService
     */
    public I_LoginService getLoginService() { return loginService; }
    
    /**
     * @return I_SessionService part of the contained SessionService.
     */
    public I_SessionService getSessionService() { return sessionService; }
    
    /**
     * @return I_InstructorStorageService part of the contained InstructorStorageService.
     */
    public I_InstructorStorageService getInstructorStorageService() { return instructorStorage; }
    
    /**
     * @return I_CourseStorageService part of the contained CourseStorageService.
     */
    public I_CourseStorageService getCourseStorageService() { return courseStorage; }
    
    private void initServices()
    {
        this.traineeStorage = new TraineeStorageService();
        this.courseStorage = new CourseStorageService();
        this.instructorStorage = new InstructorStorageService();
        
        this.signUpService = new SignUpService(traineeStorage);
        this.loginService = new LoginService(traineeStorage);
        this.sessionService = new SessionService(traineeStorage, courseStorage);
    }
    
    private void fillDatabases()
    {
        Instructor donaldTrump = new Instructor("Doanld", "Trump", 1, "donald@trump.org", "1twit_ter", 'M', 73);
        Instructor kimKardashian = new Instructor("Kim", "Kardashian", 14, "kim@gmail.com", "to_west", 'F', 39);
        Instructor justinBieber = new Instructor("Justin", "Bieber", 7, "jb@bieber.com", "cool_guy", 'M', 25);
        Instructor lorenGray = new Instructor("Loren", "Gray", 2, "lgray@instagram.com", "instagram333", 'F', 18);
        Instructor loganPaul = new Instructor("Logan", "Paul", 12, "paul@thebro.com", "you_tube_star", 'M', 24);
        Instructor kylieJenner = new Instructor("Kylie", "Jenner", 32, "kylie@fame.com", "im_the_best", 'F', 22);
        
        Course cng351 = new Course("Database Design", justinBieber, 1.45F, true);
        Course psir302 = new Course("Comparative Politics", donaldTrump, 1.15F, true);
        Course art190 = new Course("Music Theory", loganPaul, 1.15F, true);
        Course mat120 = new Course("Advanced Calculus", kimKardashian, 2.20F, false);
        Course psyc403 = new Course("Clinical Psychology", lorenGray, 0.45F, false);
        Course eee365 = new Course("Logic Design", kylieJenner, 1.3F, false);
        
        instructorStorage.addInstructor(donaldTrump);
        instructorStorage.addInstructor(kimKardashian);
        instructorStorage.addInstructor(justinBieber);
        instructorStorage.addInstructor(lorenGray);
        instructorStorage.addInstructor(loganPaul);
        instructorStorage.addInstructor(kylieJenner);
        
        courseStorage.addCourse(cng351);
        courseStorage.addCourse(psir302);
        courseStorage.addCourse(mat120);
        courseStorage.addCourse(psyc403);
        courseStorage.addCourse(art190);
        courseStorage.addCourse(eee365);
    }
    
    private I_LoginService loginService;
    private I_SignUpService signUpService;
    private I_SessionService sessionService;
    
    
    private TraineeStorageService traineeStorage;
    private InstructorStorageService instructorStorage;
    private CourseStorageService courseStorage;
}
