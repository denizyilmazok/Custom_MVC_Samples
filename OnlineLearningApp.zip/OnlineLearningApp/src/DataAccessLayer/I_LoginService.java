package DataAccessLayer;

/**
 * This interface designed to provide required functionality for login scenario.
 */
public interface I_LoginService
{
    public boolean isCredentialExist(String email);
    public boolean isCredentialCorrect(String email, String password);
    public boolean sendLoginRequest(String email, String password);
}
