package DataAccessLayer;

import java.util.ArrayList;

/**
* This interface exposes read only data access of Course database to the outside world with some additional helper functions.
*/
public interface I_CourseStorageService
{
    /**
     * Notice that, read only record type is enforced in the signature, which will be implemented by the storage service.
     * @return read only list of courses from the database.
     */
    public ArrayList<CourseStorageService.CourseReadOnly> getOfferedCourses();
    
    /**
     * Allows outside world to query whether course with given name exist.
     * @param courseName is the name of the course, which client wants know whether it is exist.
     * @return true if course with given name exist in the database, otherwise returns false.
     */
    public boolean isCourseExist(String courseName);
    
    /**
     * Allows outside world to query whether course with given name is premium or not.
     * @param courseName is the name of the course, which client wants know it's premium status.
     * @return true if queried course is premium, otherwise returns false to indicate course is not premium.
     */
    public boolean isPremiumCourse(String courseName);
}
