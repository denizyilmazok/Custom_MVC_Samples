package DataAccessLayer;

import DataAccessLayer.CourseStorageService.CourseReadOnly;
import java.util.ArrayList;


/**
 * This interface is designed to provide functionality required when trainee is authenticated and using the application.
 */
public interface I_SessionService
{
    boolean isSessionActive();
    void endCurrentSession();
    String getActiveUser_Email();
    String getActiveUser_Name();
    String getActiveUser_Surname();
    char getActiveUser_Gender();
    int getActiveUser_Age();
    boolean isActiveUser_PremiumMember();
    UserType getActiveUser_Type();
    
    String getActiveUser_Institution();
    String getActiveUser_Job();
    String getActiveUser_Position();
    
    ArrayList<CourseReadOnly> getActiveUser_EnrolledCourses();
    boolean isActiveUser_EnrolledTo(String courseName);
    
    float getActiveUser_Credit();
    float getActiveUser_MonthlyFee();
    
    
    boolean setActiveUser_EnrollTo(String courseName);
    boolean setActiveUser_WithdrawFrom(String courseName);
    void setActiveUser_PremiumStatus(boolean status);
}
