package DataAccessLayer;

import DataModels.Course;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Represents a hypothetical database which stores information for courses.
 */
public class CourseStorageService implements I_CourseStorageService
{
    CourseStorageService()
    { this.db = new HashMap<>(); }
    
    
    /**
     * 
     * @return read only list of all courses in the database.
     */
    public ArrayList<CourseReadOnly> getOfferedCourses()
    { 
        ArrayList<Course> source = new ArrayList<>(db.values()); 
        ArrayList<CourseReadOnly> result = new ArrayList<>();
        
        for(Course current : source)
        {
            result.add(new CourseReadOnly(current));
        }
        
        return result;
    }
    
    public boolean isCourseExist(String courseName)
    { return db.containsKey(courseName); }
    
    public boolean isPremiumCourse(String courseName)
    {
        if(!isCourseExist(courseName))
            return false;
        else
            return db.get(courseName).isPremiumCourse();
    }
    
    /**
     * @param record new modifiable course record to put into a database.
     */
    void addCourse(Course record)
    { db.putIfAbsent(record.getName(), record); }
    
    
    /**
     * Does not use any safe-guards for anomalies, because, accessing objects have their 
     * internal state to indicate when to access it.
     * 
     * @param name is the name of actual requested record.
     * @return actual course record which matches with given name.
     */
    Course getCourseByName(String name)
    { return (Course) db.get(name); }
    
    
    /**
     * Does not use any safe-guards for anomalies, because, accessing objects have their 
     * internal state to indicate when to access it.
     * 
     * @param original is the actual course record in the database.
     * @return read only copy of the given actual record.
     */
    CourseReadOnly getReadOnlyCourse(Course original)
    { return new CourseReadOnly(original); }
    
    
    /**
     * Represents read only copy of the actual course record in the database.
     */
    public class CourseReadOnly
    {
        CourseReadOnly(Course original)
        {
            _name = original.getName();
            _instructorName = original.getInstructor().getName();
            _instructorSurname = original.getInstructor().getSurname();
            _duration = original.getDuration();
            _premium = original.isPremiumCourse();
        }
        
        public String name(){ return _name; }
        public String instructorName() { return _instructorName; }
        public String instructorSurname() { return _instructorSurname; }
        public float duration() { return _duration; }
        public boolean isPremium() { return _premium; }
        
        private String _name, _instructorName, _instructorSurname;
        private float _duration;
        private boolean _premium;
    }
    
    private HashMap<String, Course> db;
}
