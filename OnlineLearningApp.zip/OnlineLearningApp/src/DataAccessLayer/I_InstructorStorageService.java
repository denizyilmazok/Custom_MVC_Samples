package DataAccessLayer;

import java.util.ArrayList;


/**
* This interface exposes read only data access of Instructor database to the outside world.
*/
public interface I_InstructorStorageService
{
    /**
     * Notice that, read only record type is enforced in the signature, which will be implemented by the storage service.
     * @return read only list of instructors from the database.
     */
    public ArrayList<InstructorStorageService.InstructorReadOnly> getInstructorList();
}
