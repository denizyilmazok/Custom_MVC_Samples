package DataAccessLayer;

import DataModels.Instructor;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Represents a hypothetical database which stores information for instructors.
 */
public class InstructorStorageService implements I_InstructorStorageService
{
    InstructorStorageService()
    { db = new HashMap<>(); }
    
    
    /**
     * @return read only list of stored instructor records in the database.
     */
    public ArrayList<InstructorReadOnly> getInstructorList()
    { 
         ArrayList<InstructorReadOnly> result = new ArrayList<>();
         ArrayList<Instructor> source = new ArrayList<>(db.values());
         
         for(Instructor current : source)
         {
             result.add(new InstructorReadOnly(current));
         }
         
         return result;
    }
    
    
    /**
     * @param record new modifiable instructor record to put into a database.
     */
    void addInstructor(Instructor record)
    { db.putIfAbsent(record.getEmail(), record); }
    
    
    /**
     * Represents a read only database record for matching instructor in database.
     */
    public class InstructorReadOnly
    {
        InstructorReadOnly(Instructor original)
        {
            _ID = original.getID();
            _name = original.getName();
            _surname = original.getSurname();
            _email = original.getEmail();
            _age = original.getAge();
            _gender = original.getGender();
        }
        
        public int ID() { return _ID; }
        public String name() { return _name; }
        public String surname() { return _surname; }
        public String email() { return _email; }
        public int age() { return _age; }
        public char gender() { return _gender; }
        
        private String _name, _surname, _email;
        private int _ID, _age;
        private char _gender;
    }
    
    private HashMap<String, Instructor> db;
}
