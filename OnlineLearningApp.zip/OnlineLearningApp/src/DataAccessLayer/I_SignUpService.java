package DataAccessLayer;

/**
 * This interface is designed to provide required functionality for signing up scenario.
 */
public interface I_SignUpService
{
    void setRegistration_Name(String name);
    void setRegistration_Surname(String surname);
    void setRegistration_Email(String email);
    void setRegistration_Password(String password);
    void setRegistration_Gender(char gender);
    void setRegistration_Age(int age);
    void setRegistration_Type(UserType type);
    void setRegistration_Institution(String institution);
    void setRegistration_Job(String job);
    void setRegistration_Position(String position);
    void setRegistration_PremiumStatus(boolean status);
    
    boolean sendRegistrationRequest();
    

    boolean isRegistration_AlreadyExist();
    boolean isRegistration_DataFormatValid();
    boolean isRegistration_NameValid();
    boolean isRegistration_SurnameValid();
    boolean isRegistration_EmailValid();
    boolean isRegistration_PasswordValid();
    boolean isRegistration_GenderValid();
    boolean isRegistration_AgeValid();
    boolean isRegistration_InstitutionValid();
    boolean isRegistration_JobValid();
    boolean isRegistration_PositionValid();
}
