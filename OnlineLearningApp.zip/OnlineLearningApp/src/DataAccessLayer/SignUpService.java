package DataAccessLayer;

import DataModels.NonStudent;
import DataModels.Student;
import DataModels.Trainee;

/**
 * 
 * Provides necessary functionality for signing up scenario.
 * Does that by talking predefined set of APIs on trainee database.
 * 
 * It caches record for signing up. This, cached record is created by client code.
 * Client creates cached record with appropriate setters. 
 * Then, this service sends signup request for cached request. 
 * If request fails, client can run checks on the cached record to find why request failed.
 */
public class SignUpService implements I_SignUpService
{
    SignUpService(TraineeStorageService storage)
    { this.storage = storage; }
    
    @Override
    public void setRegistration_Name(String name) { this.name = name; }

    @Override
    public void setRegistration_Surname(String surname) { this.surname = surname; }

    @Override
    public void setRegistration_Email(String email) { this.email = email; }

    @Override
    public void setRegistration_Password(String password) { this.password = password; }

    @Override
    public void setRegistration_Gender(char gender) { this.gender = gender; }

    @Override
    public void setRegistration_Age(int age) { this.age = age; }

    @Override
    public void setRegistration_Type(UserType type) { this.registartionType = type; }

    @Override
    public void setRegistration_Institution(String institution) { this.institution = institution; }

    @Override
    public void setRegistration_Job(String job) { this.job = job; }

    @Override
    public void setRegistration_Position(String position) { this.position = position; }

    @Override
    public void setRegistration_PremiumStatus(boolean status) { this.premiumStatus = status; }

    
    
    /**
     * Sends sign up request for cached record.
     * @return true if sign up request is accepted, otherwise false.
     */
    @Override
    public boolean sendRegistrationRequest()
    {
        // by default create student record.
        cachedTrainee = new Student(this.name, 
                                        this.surname, 
                                        this.email, 
                                        this.password, 
                                        this.institution, 
                                        this.gender, 
                                        this.age, 
                                        this.premiumStatus);
        
        
        if(registartionType == UserType.NON_STUDENT)
        {   // convert default record to a non-student.
            cachedTrainee = new NonStudent(cachedTrainee, this.job, this.position);
        }
        
        if(isRegistration_AlreadyExist() || !isRegistration_DataFormatValid())
            return false;
        else
        {
            if(this.registartionType == UserType.STUDENT)
                storage.registerStudent((Student)cachedTrainee);
            else
                storage.registerNonStudent((NonStudent)cachedTrainee);
            
            return true;
        }
    }

    
    
    @Override
    public boolean isRegistration_AlreadyExist()
    { return storage.isTraineeExistWith(cachedTrainee.getEmail()); }

    @Override
    public boolean isRegistration_DataFormatValid()
    {
        try
        {
            return ((Student) cachedTrainee).isTraineeInfoValid();
        }
        catch(ClassCastException studentExp)
        {
            return ((NonStudent)cachedTrainee).isTraineeInfoValid();
        }
    }

    @Override
    public boolean isRegistration_NameValid() { return cachedTrainee.isNameValid(); }

    @Override
    public boolean isRegistration_SurnameValid() { return cachedTrainee.isSurnameValid(); }

    @Override
    public boolean isRegistration_EmailValid() { return cachedTrainee.isEmailValid(); }

    @Override
    public boolean isRegistration_PasswordValid() { return cachedTrainee.isPasswordValid(); }

    @Override
    public boolean isRegistration_GenderValid() { return cachedTrainee.isGenderValid(); }

    @Override
    public boolean isRegistration_AgeValid() { return cachedTrainee.isAgeValid(); }

    
    /**
     * @throws UnsupportedOperationException if institution check is performed on the non-student record.
     */
    @Override
    public boolean isRegistration_InstitutionValid()
    {
        try
        {
            return ((Student)cachedTrainee).isInstitutionValid();
        }
        catch(ClassCastException nonStudentExp)
        {
            throw new UnsupportedOperationException("Can't check validation of Institution for NonStudent");
        }
    }

    
    /**
     * @throws UnsupportedOperationException exception if job check is performed on the student record.
     */
    @Override
    public boolean isRegistration_JobValid()
    {
        try
        {
            return ((NonStudent)cachedTrainee).isJobValid();
        }
        catch(ClassCastException studentExp)
        {
            throw new UnsupportedOperationException("Can't check validation of Job for Student");
        }
    }

    
    /**
     * @throws UnsupportedOperationException exception if position check is performed on the student record.
     */
    @Override
    public boolean isRegistration_PositionValid()
    {
        try
        {
            return ((NonStudent)cachedTrainee).isPositionValid();
        }
        catch(ClassCastException studentExp)
        {
            throw new UnsupportedOperationException("Can't check validation of Position for Student");
        }
    }
    
    private TraineeStorageService storage;
    
    private String name, surname, email, password, institution, job, position;
    char gender;
    int age;
    boolean premiumStatus;
    UserType registartionType;
    
    private Trainee cachedTrainee = null;
}
