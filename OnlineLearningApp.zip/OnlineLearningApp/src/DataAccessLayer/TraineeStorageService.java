package DataAccessLayer;

import DataModels.NonStudent;
import DataModels.Student;
import DataModels.Trainee;
import java.util.HashMap;

/**
 * Represents a hypothetical database which stores information for trainees.
 * 
 * It stores an additional type of trainee reference to a record in database.
 * Which represents currently authenticated trainee.
 * It does not authenticate trainee itself. It only stores currently authenticated one. 
 * Also, when de-authentication takes place it releases mentioned reference.
 * So, it only provides storage requirements for authentication services. 
 * It only stores who is authentic. When and why to authenticate someone is job of the clients.
 * 
 * In addition it provides special set of APIs fro signup service.
 */
public class TraineeStorageService
{
    TraineeStorageService()
    {
        db = new HashMap<>();
        this.activeUser = null;
    }
    
    
    boolean isTraineeExistWith(String email) 
    {
        boolean result = db.containsKey(email); 
        return result;
    }
    
    boolean isTraineeCredentialMatchesWith(String email, String password)
    { return db.get(email).getPassword().equals(password); }
    
    void registerStudent(Student student) 
    { db.put(student.getEmail(), student); }
    
    void registerNonStudent(NonStudent nonStudent) 
    { db.put(nonStudent.getEmail(), nonStudent); }
    
    private Trainee activeUser;
    void startSessionsForUserWith(String email) { this.activeUser = db.get(email); }
    
    void endSessionForUserWith(String email) 
    {
        if(getActiveUser().getEmail().equals(email))
            this.activeUser = null;
    }
    
    Trainee getActiveUser() { return activeUser; }
    
    private HashMap<String, Trainee> db;
}