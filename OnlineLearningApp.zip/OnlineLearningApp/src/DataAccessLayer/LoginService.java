package DataAccessLayer;

/**
 * 
 * Provides necessary functionality for login scenario.
 * This service is responsible for starting a new session for trainee in the app.
 * Does that by talking predefined set of APIs on trainee database.
 */
public class LoginService implements I_LoginService
{
    LoginService(TraineeStorageService storage)
    { this.storage = storage; }
    
    
    /**Checks whether user exist with given email in DB.
     * @param email is the required identifier for credential checking.
     * @return true if user with matching email is exist.
     */
    @Override
    public boolean isCredentialExist(String email)
    { return storage.isTraineeExistWith(email); }

    
    /**Checks whether given email and password match each other.
     * @param email is the identifier which should match with the password. 
     * @param password is authentcative token which should match with an given email.
     * @return true when given credentials are correct, otherwise false.
     */
    @Override
    public boolean isCredentialCorrect(String email, String password)
    { return storage.isTraineeCredentialMatchesWith(email, password); }

    
    /**Attempts login with given credentials. If attempt is successful, then, authenticates trainee.
     * @param email username for wanted login request.
     * @param password authentcative token for wanted login request.
     * @return returns true to indicate login was successful and false to indicate login request rejected.
    */
    @Override
    public boolean sendLoginRequest(String email, String password)
    { 
        if(!isCredentialExist(email) || !isCredentialCorrect(email, password))
            return false;
        else
        {
            storage.startSessionsForUserWith(email);
            return true;
        }
    }
    
    private TraineeStorageService storage;
}
