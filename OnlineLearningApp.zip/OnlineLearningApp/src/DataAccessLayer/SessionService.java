package DataAccessLayer;

import DataAccessLayer.CourseStorageService.CourseReadOnly;
import DataModels.Course;
import DataModels.IPerformance;
import DataModels.NonStudent;
import DataModels.Student;
import java.util.ArrayList;

/**
 * Provides required functionality for when trainee is authenticated an using the application.
 * It does this by using set of APIs on the trainee database and course database.
 * Although this service is not responsible for starting a session for trainee, 
 * it is the one responsible for ending the session.
 * 
 * Note: Purposely, this class does not allow any kind of access to password of trainee. 
 * Because, in the requirements it's not specified that, user must be able to update or display his/her password. 
 */
public class SessionService implements I_SessionService
{
    SessionService(TraineeStorageService traineeStorage, CourseStorageService courseStorage)
    {
        this.traineeStorage = traineeStorage;
        this.courseStorage = courseStorage;
    }
    
    
   /**
     * Checks whether trainee is still authenticated.
     */
    @Override
    public boolean isSessionActive()
    { return (traineeStorage.getActiveUser() != null); }
    
    
   /**
     * De-authenticates currently logged in trainee.
     */
    @Override
    public void endCurrentSession()
    { traineeStorage.endSessionForUserWith(traineeStorage.getActiveUser().getEmail()); }
    
    
   /**
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
        @Override
    public String getActiveUser_Email()
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get Email for not logged in user.");
        else
            return traineeStorage.getActiveUser().getEmail();
    }
    
    
   /**
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public String getActiveUser_Name()
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get Name for not logged in user.");
        else
            return traineeStorage.getActiveUser().getName();
    }

    
   /**
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public String getActiveUser_Surname()
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get Surname for not logged in user.");
        else
            return traineeStorage.getActiveUser().getSurname();
    }

    
   /**
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public char getActiveUser_Gender()
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get Gender for not logged in user.");
        else
            return traineeStorage.getActiveUser().getGender();
    }

    
   /**
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public int getActiveUser_Age()
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get Age for not logged in user.");
        else
            return traineeStorage.getActiveUser().getAge();
    }

    
   /**
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public boolean isActiveUser_PremiumMember()
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get PremiumStatus for not logged in user.");
        else
            return traineeStorage.getActiveUser().isPremiumMember();
    }

    
   /**
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public UserType getActiveUser_Type()
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get Type for not logged in user.");
        
        try
        {
            Student currentStudent = (Student) traineeStorage.getActiveUser();
            return UserType.STUDENT;
        }
        catch(ClassCastException studentExp)
        {
            return UserType.NON_STUDENT;
        }
    }

    
    /**
     * Only applies to trainees which are student.
     * @return institution of the currently authenticated trainee.
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public String getActiveUser_Institution()
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get Institution for not logged in user.");
        
        if(getActiveUser_Type() == UserType.NON_STUDENT)
            throw new UnsupportedOperationException("Can't get Institution for logged in Non-Student.");
        else
        {
            return ((Student) traineeStorage.getActiveUser()).getInstitution();
        }
    }

    
    /**
     * Only applies to trainees which are non-student.
     * @return job of the currently authenticated trainee.
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public String getActiveUser_Job()
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get Job for not logged in user.");
        
        if(getActiveUser_Type() == UserType.STUDENT)
            throw new UnsupportedOperationException("Can't get Job for logged in Student.");
        else
            return ((NonStudent)traineeStorage.getActiveUser()).getJob();
    }

    
    /**
     * Only applies to trainees which are non-student.
     * @return position of the currently authenticated trainee.
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public String getActiveUser_Position()
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get Position for not logged in user.");
        
        if(getActiveUser_Type() == UserType.STUDENT)
            throw new UnsupportedOperationException("Can't get Position for logged in Student.");
        else
            return ((NonStudent)traineeStorage.getActiveUser()).getPosition();
    }
    
    
    /**
     * @return read only course list of the currently authenticated trainee.
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
     @Override
    public ArrayList<CourseReadOnly> getActiveUser_EnrolledCourses()
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get EnrolledCourses for not logged in user.");
        
        ArrayList<Course> source = new ArrayList<>(traineeStorage.getActiveUser().getEnrolledCourses());
        ArrayList<CourseReadOnly> result = new ArrayList<>();
        
        for(Course current : source)
        {
            result.add(courseStorage.getReadOnlyCourse(current));
        }
        
        return result;
    }
    
    
    /**
     * @param courseName is the name of the course which want to check enrollment status.
     * @return true, if currently active trainee is enrolled to course with given name.
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public boolean isActiveUser_EnrolledTo(String courseName)
    { 
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't enroll a Course for not logged in user.");
        else if(!courseStorage.isCourseExist(courseName))
            return false;
        
        Course courseToCheck = courseStorage.getCourseByName(courseName);
        
        return traineeStorage.getActiveUser().isEnrolledTo(courseToCheck); 
    }
    
    
    /**
     * @return calculated credit of currently authenticated trainee.
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public float getActiveUser_Credit()
    { 
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get Credit for not logged in user.");
        
        return ((IPerformance) traineeStorage.getActiveUser()).credit(); 
    }
    
    
    /**
     * @return calculated monthly fee of the currently authenticated employee.
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public float getActiveUser_MonthlyFee()
    { 
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't get MonthlyFee for not logged in user.");
        
        return ((IPerformance)traineeStorage.getActiveUser()).monthlyFee(); 
    }
    
    
    /** 
     * @param courseName is the name of the course, which currently authenticated trainee wants to enroll.
     * @return true if enrollment attempt is successful, otherwise, returns false.
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
     @Override
    public boolean setActiveUser_EnrollTo(String courseName)
    { 
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't enroll a Course for not logged in user.");
        else if(!courseStorage.isCourseExist(courseName))
            return false;
        
        Course courseToEnroll = courseStorage.getCourseByName(courseName);
        
        return traineeStorage.getActiveUser().enrollTo(courseToEnroll); 
    }
    
    
    /**
     * @param courseName is the name of the course, which currently authenticated trainee wants to withdraw.
     * @return true if withdrawal attempt is successful, otherwise, returns false.
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public boolean setActiveUser_WithdrawFrom(String courseName)
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't withdraw from a Course for not logged in user.");
        else if(!courseStorage.isCourseExist(courseName))
            return false;
        
        Course courseToWithdraw = courseStorage.getCourseByName(courseName);
        
        return traineeStorage.getActiveUser().withdrawFrom(courseToWithdraw);
    }

    
    /** 
     * It does not perform any semantic checks on premium status of the employee.
     * Such as, if trainee who enrolled 3 courses can't cancel premium membership.
     * Semantics are governed by the client, it only performs premium status update securely.
     * @param status is new premium membership status of the currently authenticated trainee.
     * @throws UnsupportedOperationException if de-authorized access id made.
     */
    @Override
    public void setActiveUser_PremiumStatus(boolean status)
    {
        if(!isSessionActive())
            throw new UnsupportedOperationException("Can't set PremiumStatus for not logged in user.");
        
        traineeStorage.getActiveUser().setPremiumMember(status); 
    }
    
    private TraineeStorageService traineeStorage;
    private CourseStorageService courseStorage;
}
