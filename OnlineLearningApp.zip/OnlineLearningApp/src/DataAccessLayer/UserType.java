package DataAccessLayer;

/**
 * Constants for describing trainee's account type.
 */
public enum UserType{STUDENT, NON_STUDENT}
