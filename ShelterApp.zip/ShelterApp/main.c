#include <stdio.h>
#include "UserInterface/UI_Functions.h"

int main()
{
    printf("----   ShelterApp   ---- | CNG 315 Assignment 2 -> Fuat Deniz YILMAZOK - 2079465\n");

    // Debug tip: setting CONSTRAINT_DB_DEFAULT_SIZE = 5 and launching the app will be good simulation.
    Database *database = create_Database(CONSTRAINT_DB_DEFAULT_SIZE);
    int menuSelection;

    while(true)
    {
        show_Menu(database);
        menuSelection = waitUntilMenuSelectionRead();
        database = decideAndPerformUseCase(menuSelection, database);
    }

    return 0;
}
