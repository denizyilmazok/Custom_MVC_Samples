#ifndef DATABASE_ENTRY_H
#define DATABASE_ENTRY_H

#include <stdlib.h>
#include <string.h>
#include <stdbool.h> // Included to use bool data type.

#define CONSTRAINT_DOG_NAME_LENGTH 30

// This file contains data model for representing a dog and functions to create/modify concrete variables of them.
// Data model represents a database entry.
//
// Functions in this module designed to prevent clients from creating/manuplating data structures manually.

// Sturcutre for representing date information of database entry.
typedef struct
{
    short day;
    short month;
    short year;
} Date;


// Data model of Dog.
// Represents a database entry.
typedef struct
{
    int id; // Primary key of entry.
    char name[CONSTRAINT_DOG_NAME_LENGTH];
    float weight;
    float height;

    Date *dateEntry;
    Date *dateLeave; // When this value is NULL, indicates dog as un-adopted.
} Dog;


// Creates new date record with given values.
// Arguments are used to initialize matching fields of newly created date record.
Date *create_Date(short day, short month, short year);


// Creates new database entry with given values.
// Arguments are used to initialize matching fields of newly created database entry.
// This function leaves field *dateLeave NULL to mark created dog as un-adopted.
Dog *create_UnAdoptedDog(int id,
                         const char * const name,
                         float weight,
                         float height,
                         Date *dateEntry);


// Helper function for marking given dog as adopted.
// It sets *dateLeave to given Date argument.
void setDogAdoptionDate(Dog * const dog, Date * const dateLeave);

#endif // DATABASE_ENTRY_H
