#include "Database.h"

Database *create_Database(unsigned long size)
{
    Database *result = (Database *) malloc(sizeof (Database));
    result->arrayOfPointers = (Dog **) malloc(sizeof(Dog *) * size); // Allocate array of pointers.
    result->numeberOfUsedCells = 0;
    result->size = size;

    for(unsigned long i = 0; i < size; i++)
    {
        result->arrayOfPointers[i] = NULL; // Initialize empty table.
    }

    return result;
}

Dog *getDogById(int id, const Database * const database)
{
    unsigned long startingIndex = generateProbingIndex(id, database->size, 0);

    if(database->arrayOfPointers[startingIndex] == NULL)
    {
        return NULL;
    }
    else if(database->arrayOfPointers[startingIndex]->id == id)
    {
        return database->arrayOfPointers[startingIndex];
    }
    else // If dog was not found in the initial cell.
    {
        unsigned long increment = 1;
        unsigned long nextIndex = generateProbingIndex(id, database->size, increment);

        while(increment < database->size) // Search until probing index wraps around.
        {
            // When empty cell is encountered, it mean probing sequence does not continues anymore.
            if(database->arrayOfPointers[nextIndex] == NULL)
            {
                return NULL;
            }
            else if(database->arrayOfPointers[nextIndex]->id == id)
            {
                return database->arrayOfPointers[nextIndex];
            }
            else
            {
                ++increment;
                nextIndex = generateProbingIndex(id, database->size, increment);
            }
        }

        return NULL; // When searched item is not found in the table.
    }
}

void insertDogById(Dog *dog, Database * const database)
{
    unsigned long startingIndex = generateProbingIndex(dog->id, database->size, 0);

    if(database->arrayOfPointers[startingIndex] == NULL) // If empty place found at initial index.
    {
        database->arrayOfPointers[startingIndex] = dog;
        ++database->numeberOfUsedCells;
        return;
    }
    else if(database->arrayOfPointers[startingIndex]->id == dog->id) // If matching dog record already exits.
    {
        return;
    }
    else
    {
        unsigned long increment = 1;
        unsigned long nextIndex = generateProbingIndex(dog->id, database->size, increment);

        while(increment < database->size) // Search until probing index wraps around.
        {
            if(database->arrayOfPointers[nextIndex] == NULL) // If empty place found at newly probed index.
            {
                database->arrayOfPointers[nextIndex] = dog;
                ++database->numeberOfUsedCells;
                return; // Leave function after insertion complete.
            }
            else
            {
                ++increment;
                nextIndex = generateProbingIndex(dog->id, database->size, increment);
            }
        }

        return; // When empty place for insertion is not found.
    }
}

unsigned long generateProbingIndex(int key, unsigned long tableSize, unsigned long increment)
{
    unsigned long i = increment * increment;

    return ((key % tableSize) + i) % tableSize;
}
