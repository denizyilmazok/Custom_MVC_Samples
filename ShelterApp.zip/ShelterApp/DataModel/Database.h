#ifndef DATABASE_H
#define DATABASE_H

#include "DataModel/DatabaseEntry.h"

#define CONSTRAINT_DB_DEFAULT_SIZE 11

// This file represents a database (hash table for struct Dog *).
// Functions in this file are interface to the database. That is, they hide how data is stored/hashed etc.
// This database treats id of dog as primary key. Namely, no duplicate entries with same ids are not allowed.

typedef struct
{
    Dog **arrayOfPointers; // Hash table.

    unsigned long numeberOfUsedCells;
    unsigned long size; // Total number of cells in hash table.
} Database;


// Returns new empty database which has same size with fucntions argument.
Database *create_Database(unsigned long size);


// Searches given database for a dog with matching id.
// If dog with given id is found, then, returns database entry for it.
//      If dog with give id is not exist in db, then, returns NULL.
Dog *getDogById(int id, const Database * const database);


// Adds given dog entry to corresponding database.
// It does NOT add given entry to database when individual or combination of situations below happen:
//          - Database is full or secondary cluster is full for generated sequence.
//          - Dog with same id already exist in database.
//
// It uses id of given dog entry for addition.
void insertDogById(Dog *dog, Database * const database);


// Helper function that generates array index to be probed.
//
// Argument 'increment' is used for generating nth probing index.
//      When 'increment' is 0, function will generate initial hash location.
unsigned long generateProbingIndex(int key, unsigned long tableSize, unsigned long increment);

#endif // DATABASE_H
