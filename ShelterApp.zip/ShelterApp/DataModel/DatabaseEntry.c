#include "DatabaseEntry.h"

Date *create_Date(short day, short month, short year)
{
    Date *result = (Date *) malloc(sizeof (Date));
    result->day = day;
    result->month = month;
    result->year = year;

    return result;
}

Dog *create_UnAdoptedDog(int id,
                         const char * const name,
                         float weight,
                         float height,
                         Date *dateEntry)
{
    Dog *result = (Dog *) malloc(sizeof (Dog));

    result->id = id;
    strcpy(result->name, name); // Initialize name.
    result->weight = weight;
    result->height = height;
    result->dateEntry = dateEntry;

    result->dateLeave = NULL;

    return result;
}

void setDogAdoptionDate(Dog * const dog, Date * const dateLeave)
{
    dog->dateLeave = dateLeave;
}
