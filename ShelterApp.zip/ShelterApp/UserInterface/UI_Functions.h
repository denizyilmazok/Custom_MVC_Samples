#ifndef UI_FUNCTIONS_H
#define UI_FUNCTIONS_H

#include <stdio.h>
#include "DataAccessModule/DataAccessServices.h"

// This module contains helper functions and functions will be used directly by main(), for performing UI functionality.

// Prints menu items and database statistics to screen.
void show_Menu(const Database * const database);


// Reads menu item selected by user. Until user enters valid input, re-prints input dialog.
//      When input is valid, returns selection.
int waitUntilMenuSelectionRead();


// This function receives menu selection and database.
// Based on menu selection, it dispatches responsibility to it's sub functions.
// The reason it takes database as an argument and returns a database is that,
//      some sub-functions receives database and returns modified version of it.
//      So, this function gives database to these functions and returns back modified version from these functions.
//      Returned database will be the final version of the database.
//
// It's sub-fucntions designated as performUseCase_XXXXXX
Database *decideAndPerformUseCase(int selectedMenuItem, Database * database);


// Sub-function for performing searching a dog use case.
// Reads id for dog from user. Then, makes a search requres to DAS.
//      Then, displays the result of request.
//
// Although this function takes database as an argument, it does not modifies it.
//      Because search operations on database are read only.
void performUseCase_SearchDog(const Database * const database);


// Sub-function for performing adding an un-adopted dog use case.
// Reads necessary information for new dog from user. After that, makes add un-adopted dog requrest to DAS.
//      Then, displays the result of request.
//
// This function can modify given database and return updated version of it.
//      At extreme, it may return an a new database, when database re-hashed.
Database *performUseCase_AddUnAdoptedDog(Database *database);


// Sub-function for performing adoption of un-adopted dog use case.
// First, reads id from user. Then, searches dog with given id via DAS search request.
//      Next, If, search was successful, reads adoption date from user.
//      After that, result of search request is used for adopting dog.
//      This is achieved by, making adoption request to DAS with cached search result.
//      Finally, adoption result is printed.
//
// This function takes database as argument and returns updated version of it.
// Returned database is not a new database because, adoption requests does not increase the size of DB.
Database *performUseCase_AdoptDog(Database *database);


// Sub-function for performing exiting app use case.
// Takes database as an argument to print database statistics, before ending the app.
void performUseCase_Exit(const Database * const database);


// Helper function for displaying human readable version of ServiceRequestResult errors.
void show_ServiceRequestError(ServiceRequestResult result);


// Helper function for displaying contents of database entry for Dog.
void show_DogInfo(const Dog * const subject);

#endif // UI_FUNCTIONS_H
