#include "UI_Functions.h"

// Constants for selectable menu items.
// Not needed for outside world. So declared here.
typedef enum
{
    MENU_ITEM_SEARCH = 1,
    MENU_ITEM_ADD,
    MENU_ITEM_ADOPT,
    MENU_ITEM_EXIT
} MenuItem;

void show_Menu(const Database * const database)
{
    printf("\n");
    printf("1) Search dog\n");
    printf("2) Add new dog\n");
    printf("3) Adopt a dog\n");
    printf("4) Exit\n");
    printf("----\n");
    printf("Number of recorded dogs: %ld\n", database->numeberOfUsedCells);
    printf("Size of the database is: %ld\n", database->size);
}

int waitUntilMenuSelectionRead()
{
    int selection;
    bool isInputValid = false;

    while(!isInputValid)
    {
        printf("\n");
        printf("Enter menu selection between (1-4): ");
        scanf("%d", &selection);

        if(selection >= 1 && selection <= 4) isInputValid = true;
    }

    return selection;
}

Database *decideAndPerformUseCase(int selectedMenuItem, Database *database)
{
    switch (selectedMenuItem)
    {
        case MENU_ITEM_SEARCH:
            performUseCase_SearchDog(database);
        break;

        case MENU_ITEM_ADD:
            database = performUseCase_AddUnAdoptedDog(database);
        break;

        case MENU_ITEM_ADOPT:
            database = performUseCase_AdoptDog(database);
        break;

        default: // MENU_ITEM_EXIT
            performUseCase_Exit(database);
        break;
    }

    return database;
}

void performUseCase_SearchDog(const Database * const database)
{
    int id;

    printf("Enter unique identifier: ");
    scanf("%d", &id);

    ServiceRequestResult result =  request_searchDogInDB(id, database);

    if(!result.isSuccessful) show_ServiceRequestError(result);
    else
    {
        show_DogInfo(result.subjectDog);
        printf("\n");
    }
}

Database *performUseCase_AddUnAdoptedDog(Database *database)
{
    int id;
    char name[CONSTRAINT_DOG_NAME_LENGTH];
    float weight;
    float height;
    short dayEntry;
    short monthEntry;
    short yearEntry;

    printf("Enter unique identifier: ");
    scanf("%d", &id);

    printf("Enter name: ");
    scanf("%29s", name); // Read 29 characters.

    printf("Enter weight: ");
    scanf("%f", &weight);

    printf("Enter height: ");
    scanf("%f", &height);

    printf("Enter entry date (day.month.year):");
    scanf("%hu.%hu.%hu", &dayEntry, &monthEntry, &yearEntry); // %hu for unsiged short int

    ServiceRequestResult result;
    database = request_addUnAdoptedDogToDB(id, name, weight, height, dayEntry, monthEntry, yearEntry, &result, database);

    if(!result.isSuccessful) show_ServiceRequestError(result);
    else printf("%s has been added to the dog shelter \n", result.subjectDog->name);

    return database;
}

Database *performUseCase_AdoptDog(Database *database)
{
    int id;

    printf("Enter unique identifier: ");
    scanf("%d", &id);

    ServiceRequestResult cachedResult = request_searchDogInDB(id, database);

    // This if condition, included here for preventing show_DogInfo() from receiving NULL subjectDog.
    // If show_DogInfo() woulndn't be there, this if condition is not needed. Because, request_markDogAsAdoptedInDB() is self-protected for dangerous inputs.
    // Then question is that, why show_DogInfo() is called before request_markDogAsAdoptedInDB() ?
    //      This is because, in assignment, search result is displayed before adoption request.
    // So, when this if conditional included here, it acts like protection for REC_DOG_NOT_EXISTS_IN_DB.
    //      But, this does not mean that request_markDogAsAdoptedInDB() is not protected for REC_DOG_NOT_EXISTS_IN_DB.
    if(!cachedResult.isSuccessful) show_ServiceRequestError(cachedResult);
    else
    {
        short dayLeave, monthLeave, yearLeave;

        show_DogInfo(cachedResult.subjectDog);

        printf("Enter leave date: ");
        scanf("%hu.%hu.%hu", &dayLeave, &monthLeave, &yearLeave); // %hu for unsiged short int

        database = request_markDogAsAdoptedInDB(dayLeave, monthLeave, yearLeave, &cachedResult, database);

        // This if conditional effectively, checks for REC_INPUT_INVALID, REC_DOG_ALREADY_ADOPTED and REC_DOG_ADOPTION_DATE_BELOW_ENTRY_DATE.
        // As a result, although user may see a record for already adopted dog in the search request,
        //      adoption request will eventually be rejected.
        if(!cachedResult.isSuccessful) show_ServiceRequestError(cachedResult);
        else printf("%s has been adopted.\n", cachedResult.subjectDog->name);
    }

    return database;
}

void performUseCase_Exit(const Database * const database)
{
    printf("\n");
    printf("Ending ShelterApp with statistics below:\n");
    printf("Number of recorded dogs: %ld\n", database->numeberOfUsedCells);
    printf("Size of the database is: %ld\n", database->size);
    printf("App closed ! \n");

    system("pause");

    exit(0);
}

void show_ServiceRequestError(ServiceRequestResult result)
{
    switch (result.failureReason)
    {
        case REC_INPUT_INVALID:
            printf("Your input is invalid !\n");
        break;

        case REC_DOG_NOT_EXISTS_IN_DB:
            printf("No dog is found !\n");
        break;

        case REC_DOG_ALREADY_EXISTS_IN_DB:
            printf("ID should be unique ! \n");
        break;

        case REC_DOG_ALREADY_ADOPTED:
            printf("Dog is already adopted ! \n");
        break;

        case REC_DOG_ADOPTION_DATE_BELOW_ENTRY_DATE:
            printf("Adoption date should be equal or greater than enterance date !\n");
        break;

        default: // REC_NO_ERROR
            // There is nothing to translate.
        break;
    }
}

void show_DogInfo(const Dog * const subject)
{
    const Date * date = subject->dateEntry;
    printf("\n");
    printf("Name = %s \n", subject->name);
    printf("Weight = %.2f \n", subject->weight);
    printf("Height = %.2f \n", subject->height);
    printf("Entry Date = %hu.%hu.%hu \n", date->day, date->month, date->year);

    if(subject->dateLeave == NULL) printf("Leave Date = not adopted \n");
    else
    {
        date = subject->dateLeave;
        printf("Leave Date = %hu.%hu.%hu \n", date->day, date->month, date->year); // %hu for unsiged short int
        printf("\n");
    }
}
