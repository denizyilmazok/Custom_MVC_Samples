#ifndef DAS_REQUEST_RESULT_MODEL_H
#define DAS_REQUEST_RESULT_MODEL_H

#include "DataModel/Database.h"

// Note: DAS stands for Data Access Service
// This file is seperate from "DAS_HelperFunctions.h" and "DataAccessServices.h" to increase code readibility.

// Constants for representing request error codes.
typedef enum
{
    // REC stands for -> Request Error Code

    REC_NO_ERROR, // Indicates no error occured.

    REC_INPUT_INVALID, // Indicates input to request is violates expected criterias.

    REC_DOG_NOT_EXISTS_IN_DB, // Indicates requested dog entry is not found in DB.

    REC_DOG_ALREADY_EXISTS_IN_DB, // Indicates dog entry with same id already exists in DB.

    REC_DOG_ALREADY_ADOPTED, // Indicates given dog entry already adopted.

    REC_DOG_ADOPTION_DATE_BELOW_ENTRY_DATE // Indicates adoption date of dog comes before the entry date.

} RequestErrorCode;

// This structure represents resulf of request made to DAS.
// It is designed to be a result, which will be returned from request_XXXXXX() functions.
typedef struct
{
    bool isSuccessful; // Success status of result.
    RequestErrorCode failureReason; // Detailed description of why request is failed.
    Dog *subjectDog; // Subject database entry request is made for.

} ServiceRequestResult;

#endif // DAS_REQUEST_RESULT_MODEL_H
