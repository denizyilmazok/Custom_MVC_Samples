#ifndef DATA_ACCESS_SERVICES_H
#define DATA_ACCESS_SERVICES_H

#include "DataAccessModule/DAS_HelperFunctions.h"

// Functions in this file are bridge between client and database.
// They hide database details from client, such as, entry creation, inserting entry into db etc.
//      In addition to that, they try to minimize direct interaction with database directly.
//      Whenever there is a db access, they try to use functions provided by db modules.
//
// All of the request_XXXXXX() functions return result as in the form of ServiceRequestResult.


// Provides dog search service to the client.
// Receives id for dog to be search and database where search will performed.
// And, returns result as ServiceRequestResult.
//
// When search is successful, ServiceRequestResult will be returned as below:
//      ServiceRequestResult
//      {
//          isSuccessful = true
//          failureReason = REC_NO_ERROR
//          subjectDog = *search_entry (Matching database entry)
//      }
//
//
// In contrast, when search is un-successful, result will be like:
//      ServiceRequestResult
//      {
//          isSuccessful = false
//          failureReason = [see descriptions below]
//          subjectDog = NULL
//      }
//
// Error codes for un-successful search are:
//
//      REC_INPUT_INVALID -> when at least one of the input to the function is in-valid.
//      NOTE: Inputs are checked by isInputValidFor_SearchRequest()
//
//      REC_DOG_NOT_EXISTS_IN_DB -> when dog with matching id is nout found in db.
ServiceRequestResult request_searchDogInDB(int id, const Database * const database);


// Provides addition of un-adopted dog service to the client.
// Receives necessary fields for new dog entry as plain data types.
//      It takes it's arguments as regular data types, because, it hides db specific data operations from client.
//
// Also, receives db to be operated and ServiceRequestResult pointer to store the request result.
//
// Returns two different results in two different places.
// First one is the regular return value. Updated version of the database is returned from function.
// Second one is the ServiceRequestResult pointer, which will be provided by caller of the function.
//      Stores result of the operation to this pointer.
//
// NOTE: This function may return new database with preserved contents due to re-hashing.
//
// When addition is successful, ServiceRequestResult will be returned as below:
//      ServiceRequestResult
//      {
//          isSuccessful = true
//          failureReason = REC_NO_ERROR
//          subjectDog = *created_entry (created entry in db)
//      }
//
//
// In contrast, when addition is un-successful, result will be like:
//      ServiceRequestResult
//      {
//          isSuccessful = false
//          failureReason = [see descriptions below]
//          subjectDog = NULL
//      }
//
// Error codes for un-successful addition are:
//
//      REC_INPUT_INVALID -> when at least one of the input to the function is in-valid.
//      NOTE: Inputs are checked by isInputValidFor_AddRequest()
//
//      REC_DOG_ALREADY_EXISTS_IN_DB -> when dog with matching id is already in db.
Database *request_addUnAdoptedDogToDB(int id,
                                      const char * const name,
                                      float weight,
                                      float height,
                                      short dayEntry,
                                      short monthEntry,
                                      short yearEntry,
                                      ServiceRequestResult * const result,
                                      Database * database);


// Provides dog adoption service to the client.
// Receives adoption date as plain data type.
//
// Also, receives db to be operated and ServiceRequestResult pointer to store the request result.
// By design, this function uses given ServiceRequestResult pointer to mark dog as adopted.
//      Because, this function is designed to be used in combination with request_searchDogInDB().
//
// Returns two different results in two different places.
// First one is the regular return value. Updated version of the database is returned from function.
// Second one is the ServiceRequestResult pointer, which will be provided by caller of the function.
//      Stores result of the operation to this pointer.
//
//
// When adoption is successful, ServiceRequestResult will be returned as below:
//      ServiceRequestResult
//      {
//          isSuccessful = true
//          failureReason = REC_NO_ERROR
//          subjectDog = *adopted_entry (entry marked as adopted in db)
//      }
//
//
// In contrast, when adoption is un-successful, result will be like:
//      ServiceRequestResult
//      {
//          isSuccessful = false
//          failureReason = [see descriptions below]
//          subjectDog = Not modified (Stays as same with the result of request_searchDogInDB() )
//      }
//
// Error codes for un-successful adoption are:
//
//      REC_INPUT_INVALID -> when at least one of the input to the function is in-valid.
//      NOTE: Inputs are checked by isInputValidFor_AdoptionRequest()
//
//      REC_DOG_NOT_EXISTS_IN_DB -> when subjectDog in argument ServiceRequestResult is NULL.
//
//      REC_DOG_ALREADY_ADOPTED -> when subjectDog in argument ServiceRequestResult is already adopted.
//
//      REC_DOG_ADOPTION_DATE_BELOW_ENTRY_DATE -> When provided adoption date is below subjectDog's entry date.
Database *request_markDogAsAdoptedInDB(short dayLeave,
                                       short monthLeave,
                                       short yearLeave,
                                       ServiceRequestResult * const result,
                                       Database * const database);

#endif // DATA_ACCESS_SERVICES_H
