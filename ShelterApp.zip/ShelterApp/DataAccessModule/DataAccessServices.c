#include "DataAccessServices.h"

ServiceRequestResult request_searchDogInDB(int id, const Database * const database)
{
    ServiceRequestResult result; // Caution: No pointer - Will be used for pass by value.

    result.isSuccessful = false;
    result.subjectDog = NULL;

    if(!isInputValidFor_SearchRequest(id, database))
    {
        result.failureReason = REC_INPUT_INVALID;
    }
    else
    {
        Dog *dog = getDogById(id, database);

        if(dog == NULL)
        {
            result.failureReason = REC_DOG_NOT_EXISTS_IN_DB;
        }
        else
        {
            result.isSuccessful = true;
            result.failureReason = REC_NO_ERROR;
            result.subjectDog = dog;
        }
    }

    return result; // Return copy of the result as value.
}

Database *request_addUnAdoptedDogToDB(int id,
                                      const char * const name,
                                      float weight,
                                      float height,
                                      short dayEntry,
                                      short monthEntry,
                                      short yearEntry,
                                      ServiceRequestResult * const result,
                                      Database *database)
{
    result->isSuccessful = false;
    result->subjectDog = NULL;

    if(!isInputValidFor_AddRequest(id, name, weight, height, dayEntry, monthEntry, yearEntry, result, database))
    {
        result->failureReason = REC_INPUT_INVALID;
    }
    else if(isDogAlreadyExistsInDB(id, database))
    {
        result->failureReason = REC_DOG_ALREADY_EXISTS_IN_DB;
    }
    else
    {
        Date *dateEntry = create_Date(dayEntry, monthEntry, yearEntry);

        Dog *dog = create_UnAdoptedDog(id, name, weight, height, dateEntry);

        insertDogById(dog, database);

        if(isDBLoadFactorAboveLimit(database))
        {
            database = rehashDB(database);
        }

        result->isSuccessful = true;
        result->failureReason = REC_NO_ERROR;
        result->subjectDog = dog;
    }

    return database;
}

Database *request_markDogAsAdoptedInDB(short dayLeave,
                                       short monthLeave,
                                       short yearLeave,
                                       ServiceRequestResult * const result,
                                       Database * const database)
{
    result->isSuccessful = false;

    if(!isInputValidFor_AdoptionRequest(dayLeave, monthLeave, yearLeave, result, database))
    {
        result->failureReason = REC_INPUT_INVALID;
    }
    else
    {
        Dog * const candidate = result->subjectDog;

        if(candidate == NULL) // If dog with given id is not exist.
        {
            result->failureReason = REC_DOG_NOT_EXISTS_IN_DB;
        }
        else if(candidate->dateLeave != NULL) // If dog is already adopted.
        {
            result->failureReason = REC_DOG_ALREADY_ADOPTED;
        }
        // If date of leave logically does NOT make sense.
        else if(!isAdoptionDateAtLeastEntryDate(dayLeave, monthLeave, yearLeave, result->subjectDog->dateEntry))
        {
            result->failureReason = REC_DOG_ADOPTION_DATE_BELOW_ENTRY_DATE;
        }
        else
        {
            Date *dateLeave = create_Date(dayLeave, monthLeave, yearLeave);
            setDogAdoptionDate(candidate, dateLeave);

            result->isSuccessful = true;
            result->failureReason = REC_NO_ERROR;
            result->subjectDog = candidate;
        }
    }

    return database;
}
