#include "DAS_HelperFunctions.h"

// This function uses greatest factor to check whether number is prime or not.
// Let's consider number 81. sqrt(81) = 9. That means, when we write "k * 9 = 81", k should always be smaller or equal to 9.
// If number is not perfect square, k can only be SMALLER than greatest factor. For example, sqrt(133) ~ 11.53
// But, k can never exceed the greatest factor.
//
// Consider, "k * 3 = 81", then k = 27. Here 27 is greater than 9. So, isn't 9 is the greatest factor ??
// Let's write 81 as factor pairs, | 27 * 3 |  9 * 9  | 1 * 81 |. Pairs reveals that, when 9 exist, other factor can't exceed 9.
//
// Then, when we start a loop with variable i. Where loop starts from i = 2.
// And, by setting upper bound for loop sqrt(function_argument).
// We will get
//      for(i = 2; i<= sqrt(arg); ,i++)
//      {
//          if(arg/i == 0)
//      }
//
// This means we should check factors until (including) sqrt(arg).
// And, this gives us O(sqrt(n)) complexity.
//
// https://www.youtube.com/watch?v=ga9N_ey4La4
// https://www.youtube.com/watch?v=T0XbxCYLBmc
// https://www.geeksforgeeks.org/c-program-to-check-whether-a-number-is-prime-or-not/
// https://www.programiz.com/c-programming/examples/prime-number
// https://stackoverflow.com/questions/5811151/why-do-we-check-up-to-the-square-root-of-a-prime-number-to-determine-if-it-is-pr
bool isPrimeNumber(unsigned long number)
{
    if(number <= 1) return false; // 1 is not prime number

    unsigned long upperBound = sqrt(number); // Find the greatest factor.

    for(unsigned long i = 2; i <= upperBound; i++)
    {
        if(number % i == 0)
        {
            return false;
        }
    }

    return true;
}

unsigned long getNextPrimeNumber(unsigned long current)
{
    ++current; // Try next number immediately.

    if(isPrimeNumber(current))
    {
        return current;
    }

    while(!isPrimeNumber(current)) // Until next prime number is found.
    {
        ++current;
    }

    return current;
}

bool isDogAlreadyExistsInDB(int id, const Database * const database)
{
    const Dog *dog = getDogById(id, database);

    if(dog == NULL) return false;
    else return true;
}

bool isDBLoadFactorAboveLimit(const Database * const database)
{
    float allowedLimit = CONSTRAINT_DB_LOAD_FACTOR;
    float currentLoadFactor = ((float) database->numeberOfUsedCells) / ((float) database->size);

    if(currentLoadFactor > allowedLimit) return true;
    else return false;
}

Database *rehashDB(Database *oldDB)
{
    unsigned long newDBSize = getNextPrimeNumber(oldDB->size);
    Database *newDB = create_Database(newDBSize);
    Dog *currentEntry = NULL;

    for(unsigned long i = 0; i < oldDB->size; i++)
    {
        currentEntry = oldDB->arrayOfPointers[i];
        if(currentEntry != NULL)
        {
            // No re-allocation for *currentEntry.
            // Make new array cell point to already allocated dog record.
            insertDogById(currentEntry, newDB);
        }
    }

    // Remove *oldDB and it's unused contents from memory.
    for(unsigned long i = 0; i < oldDB->size; i++)
    {
        oldDB->arrayOfPointers[i] = NULL; // Detach old array cells from database entries.
        free(oldDB->arrayOfPointers[i]);
    }
    free(oldDB->arrayOfPointers);
    free(oldDB);

    return newDB;
}

bool isAdoptionDateAtLeastEntryDate(short dayLeave, short monthLeave, short yearLeave, const Date * const dateEnter)
{
    bool result = true;

    if(yearLeave < dateEnter->year) // If year is below entry year.
    {
        result = false;
    }
    else if(yearLeave == dateEnter->year) // If years are same.
    {
        if(dayLeave < dateEnter->day || monthLeave < dateEnter->month) result = false;
    }

    return result;
}

bool isInputValidFor_SearchRequest(short id, const Database * const database)
{
    if(!isValidInput_ID(id) || !isValidInput_DB(database)) return false;
    else return true;
}


bool isInputValidFor_AddRequest(int id,
                               const char * const name,
                               float weight,
                               float height,
                               short dayEntry,
                               short monthEntry,
                               short yearEntry,
                               ServiceRequestResult * const result,
                               const Database * const database)
{
    if( !isValidInput_ID(id) ||
        !isValidInput_Name(name) ||
        !isValidInput_Weight(weight) ||
        !isValidInput_Height(height) ||
        !isValidInput_Day(dayEntry) ||
        !isValidInput_Month(monthEntry) ||
        !isValidInput_Year(yearEntry) ||
        !isValidInput_ServiceRequestResult(result) ||
        !isValidInput_DB(database))
    {
        return false;
    }

    return true;
}


bool isInputValidFor_AdoptionRequest(short dayLeave,
                                     short monthLeave,
                                     short yearLeave,
                                     ServiceRequestResult * const result,
                                     const Database * const database)
{
    if(!isValidInput_Day(dayLeave) ||
       !isValidInput_Month(monthLeave) ||
       !isValidInput_Year(yearLeave) ||
       !isValidInput_ServiceRequestResult(result) ||
       !isValidInput_DB(database))
    {
        return false;
    }

    return true;
}


bool isValidInput_ID(int id)
{
    if(id <= 0) return false;
    else return true;
}

bool isValidInput_Name(const char * const name)
{
    if(name == NULL || name[0] == '\0') return false;
    else return true;
}

bool isValidInput_Weight(float weight)
{
    if(weight <= 0) return false;
    else return true;
}

bool isValidInput_Height(float height)
{
    if(height <= 0) return false;
    else return true;
}

bool isValidInput_Day(short day)
{
    if(day <= 0 || day > 31) return false;
    else return true;
}

bool isValidInput_Month(short month)
{
    if(month <= 0 || month > 12) return false;
    else return true;
}

bool isValidInput_Year(short year)
{
    if(year < 2000 || year > 2030) return false;
    else return true;
}

bool isValidInput_ServiceRequestResult(const ServiceRequestResult * const request)
{
    if(request == NULL) return false;
    else return true;
}

bool isValidInput_DB(const Database * const database)
{
    if(database == NULL) return false;
    else return true;
}
