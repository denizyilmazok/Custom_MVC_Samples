#ifndef DAS_HELPER_FUNCTIONS_H
#define DAS_HELPER_FUNCTIONS_H

#include <math.h>
#include "DataAccessModule/DAS_RequestResultModel.h"

#define CONSTRAINT_DB_LOAD_FACTOR 0.50

// Note: DAS stands for Data Access Service
// This file contains helper functions for request_XXXXXX() functions.

// Checks whether given number is a prime number or not.
// Returns true when given number is a prime number. Othwerwise, returns false.
bool isPrimeNumber(unsigned long number);


// Returns next prime number based on argument "current".
// For example, if "current" = 7, then 11 will be returned from function.
//      Given argument "current" does not need to be a prime number.
//      When "current" = 8, result will still be 11.
unsigned long getNextPrimeNumber(unsigned long current);


// Checks whether any of the dogs in db is matches with given id.
// If id matches with any of the dogs in db, then returns true. Else, returns false.
bool isDogAlreadyExistsInDB(int id, const Database * const database);


// Checks whether load factor of given database exceeds the CONSTRAINT_DB_LOAD_FACTOR.
// When limit is BELOW or EQUAL to limit, result will be false. When, limit exceeded result will true.
bool isDBLoadFactorAboveLimit(const Database * const database);


// Takes old database and creates new updated database from *oldDB.
// Returned new database have larger size than old one.
//      Resulting database will have same contents with the old one.
//
// Because of re-hashing, organisation of datastructres in new database may differ from old one.
//      But, this is hidden from user, entries in old db will be available with same id in new db.
// NOTE: This function deletes *oldDB from memory. Use with caution.
Database *rehashDB(Database *oldDB);


// Checks whether adoption date of dog greater than or equal to entry date.
// When adoption date is comes after or equal to entry date, returns true. Else, returns false.
bool isAdoptionDateAtLeastEntryDate(short dayLeave, short monthLeave, short yearLeave, const Date * const dateEnter);


// This function is designed to be used in request_searchDogInDB().
// It checks inputs to the request_searchDogInDB().
// If one or more input is in-valid, then, returns false. When all of the inputs are valid returns true.
//
// Input checks are done with: isValidInput_ID() and isValidInput_DB().
bool isInputValidFor_SearchRequest(short id, const Database * const database);


// This function is designed to be used in request_addUnAdoptedDogToDB().
// It checks inputs to the request_addUnAdoptedDogToDB().
// If one or more input is in-valid, then, returns false. When all of the inputs are valid returns true.
//
// Input checks are done with: isValidInput_ID(), isValidInput_Name(), isValidInput_Weight(),
//                             isValidInput_Height(), isValidInput_Day(), isValidInput_Month(),
//                             isValidInput_Year(), isValidInput_ServiceRequestResult(), isValidInput_DB()
bool isInputValidFor_AddRequest(int id,
                                const char * const name,
                                float weight,
                                float height,
                                short dayEntry,
                                short monthEntry,
                                short yearEntry,
                                ServiceRequestResult * const result,
                                const Database * const database);


// This function is designed to be used in request_markDogAsAdoptedInDB().
// It checks inputs to the request_markDogAsAdoptedInDB().
// If one or more input is in-valid, then, returns false. When all of the inputs are valid returns true.
//
// Input checks are done with: isValidInput_Day(), isValidInput_Month(), isValidInput_Year(),
//                             isValidInput_ServiceRequestResult(), isValidInput_DB(),
bool isInputValidFor_AdoptionRequest(short dayLeave,
                                     short monthLeave,
                                     short yearLeave,
                                     ServiceRequestResult * const result,
                                     const Database * const database);


// Returns true when given id is greaer than 0. If id is smaller or equal to zero, returns false.
bool isValidInput_ID(int id);

// If given name is NULL or empty string returns false. Otherwise, returns true.
bool isValidInput_Name(const char * const name);

// Returns false when given "weight" is below or equal to zero. Else, returns true.
bool isValidInput_Weight(float weight);

// Returns false when given "height" is below or equal to zero. Else, returns true.
bool isValidInput_Height(float height);

// Returns true when given "day" is in [1, 31] (All ends inclusive). Else, returns false.
bool isValidInput_Day(short day);

// Returns true when given "month" is in [1, 12] (All ends inclusive). Else, returns false.
bool isValidInput_Month(short month);

// Returns true when given "year" is in [2000, 2030] (All ends inclusive). Else, returns false.
bool isValidInput_Year(short year);

// Returns false when given request pointer is NULL. Otherwise, returns false.
bool isValidInput_ServiceRequestResult(const ServiceRequestResult * const request);

// Returns false when given database pointer is NULL. Otherwise, returns false.
bool isValidInput_DB(const Database * const database);

#endif // DAS_HELPER_FUNCTIONS_H
